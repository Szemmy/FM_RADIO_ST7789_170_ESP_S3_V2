#pragma once

#include <Arduino.h>
#include <Preferences.h>

struct PresetData {
  bool valid = false;
  uint16_t frequency = 0;
  char stationName[9] = {};
};

class PresetStorage {
 public:
  static constexpr uint8_t PRESET_COUNT = 6;
  // Six direct buttons plus 24 further entries in the channel menu.
  static constexpr uint8_t CHANNEL_COUNT = 30;

  bool begin();
  bool load(uint8_t slot, PresetData &preset);
  bool save(uint8_t slot, uint16_t frequency, const char *stationName);
  bool clear(uint8_t slot);
  uint8_t loadLastChannel();
  bool saveLastChannel(uint8_t slot);

 private:
  Preferences preferences_;
  bool available_ = false;
};

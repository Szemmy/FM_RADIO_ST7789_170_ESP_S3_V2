#pragma once

#include <Arduino.h>

namespace ControlConfig {

// The encoder board and push button are wired to ground when active. The
// external 10 kOhm resistors provide the pull-ups, so the ESP32's internal
// pull-ups are intentionally not enabled.
constexpr bool ACTIVE_LOW = true;
constexpr bool USE_INTERNAL_PULLUPS = false;

// Change this to true if clockwise rotation decreases the value on the
// installed encoder.
constexpr bool ENCODER_REVERSED = false;

constexpr uint8_t QUADRATURE_TRANSITIONS_PER_DETENT = 4;
constexpr uint32_t BUTTON_DEBOUNCE_MS = 30;
constexpr uint32_t BUTTON_LONG_PRESS_MS = 800;
constexpr uint32_t BUTTON_VERY_LONG_PRESS_MS = 4000;

}  // namespace ControlConfig

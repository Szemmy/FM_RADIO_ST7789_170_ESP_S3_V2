#pragma once

#include <Arduino.h>
#include <RDA5807.h>

class RadioController {
 public:
  static constexpr uint16_t MIN_FREQUENCY = 8750;   // 87.5 MHz
  static constexpr uint16_t MAX_FREQUENCY = 10800;  // 108.0 MHz
  static constexpr uint16_t FREQUENCY_STEP = 10;    // 0.1 MHz
  static constexpr uint8_t MAX_VOLUME = 15;

  bool begin(bool deviceDetected, uint16_t initialFrequency = 10000U);
  void setFrequency(uint16_t frequency);
  void tuneSteps(int8_t steps);
  void changeVolume(int8_t steps);
  void toggleMute();
  void setMuted(bool muted);
  void refreshReceptionStatus();
  bool pollRds();

  bool available() const { return available_; }
  uint16_t frequency() const { return frequency_; }
  uint8_t volume() const { return volume_; }
  bool muted() const { return muted_; }
  uint8_t rssi() const { return rssi_; }
  bool stereo() const { return stereo_; }
  bool stationValid() const { return stationValid_; }
  bool rdsSynchronized() const { return rdsSynchronized_; }
  const char *rdsStationName() const { return rdsStationName_; }
  const char *rdsProgramText() const { return rdsProgramText_; }
  uint32_t rdsRevision() const { return rdsRevision_; }

 private:
  void clearRdsData();

  RDA5807 receiver_;
  bool available_ = false;
  uint16_t frequency_ = 10000;
  uint8_t volume_ = 1;
  bool muted_ = false;
  uint8_t rssi_ = 0;
  bool stereo_ = false;
  bool stationValid_ = false;
  bool rdsSynchronized_ = false;
  char rdsStationName_[9] = {};
  char rdsProgramText_[65] = {};
  uint32_t rdsRevision_ = 0;
};

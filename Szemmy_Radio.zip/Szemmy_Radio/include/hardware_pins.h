#pragma once

#include <Arduino.h>

// Szemmy Radio - ESP32-WROOM-32 pin assignment.
namespace Pins {

// ST7789 1.9 inch, 170 x 320 pixel display (SPI).
constexpr uint8_t TFT_SCLK = 18;       // Display pin marked SCL/CLK.
constexpr uint8_t TFT_MOSI = 23;       // Display pin marked SDA/DIN.
constexpr uint8_t TFT_RST = 17;        // Display pin marked RES/RST (user: RS).
constexpr uint8_t TFT_DC = 16;
constexpr uint8_t TFT_CS = 5;
constexpr uint8_t TFT_BACKLIGHT = 32;  // AO3401A MOSFET gate.

// Rotary encoder. External 10 kOhm pull-up resistors are used.
constexpr uint8_t ENCODER_S1 = 26;
constexpr uint8_t ENCODER_S2 = 25;
constexpr uint8_t ENCODER_KEY = 27;

// Station preset buttons. External 10 kOhm pull-up resistors are used.
constexpr uint8_t BUTTON_1 = 13;
constexpr uint8_t BUTTON_2 = 14;
constexpr uint8_t BUTTON_3 = 19;
constexpr uint8_t BUTTON_4 = 33;
constexpr uint8_t BUTTON_5 = 35;  // Input only on the classic ESP32.
constexpr uint8_t BUTTON_6 = 36;  // Input only on the classic ESP32.

// Shared I2C bus for the RDA5807 and DS3231 RTC module.
constexpr uint8_t I2C_SDA = 21;
constexpr uint8_t I2C_SCL = 22;

// Infrared receiver. Its active-low output can also wake light sleep.
constexpr uint8_t IR_INPUT = 4;

}  // namespace Pins

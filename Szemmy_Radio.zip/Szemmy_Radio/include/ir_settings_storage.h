#pragma once

#include <Arduino.h>
#include <Preferences.h>

struct IrCodeData {
  bool valid = false;
  int16_t protocol = -1;
  uint16_t bits = 0;
  uint64_t value = 0;
  uint32_t address = 0;
  uint32_t command = 0;
};

class IrSettingsStorage {
 public:
  static constexpr uint8_t ACTION_COUNT = 19;

  bool begin();
  bool load(uint8_t action, IrCodeData &code);
  bool save(uint8_t action, const IrCodeData &code);

 private:
  Preferences preferences_;
  bool available_ = false;
};

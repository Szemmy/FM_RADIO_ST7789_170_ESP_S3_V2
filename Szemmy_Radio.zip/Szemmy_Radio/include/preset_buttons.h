#pragma once

#include <Arduino.h>

enum class PresetButtonEventType : uint8_t {
  NONE,
  SHORT_PRESS,
  LONG_PRESS,
};

struct PresetButtonEvent {
  PresetButtonEventType type = PresetButtonEventType::NONE;
  uint8_t slot = 0;
};

class PresetButtons {
 public:
  static constexpr uint8_t BUTTON_COUNT = 6;
  static constexpr uint32_t LONG_PRESS_MS = 4000;

  void begin();
  PresetButtonEvent update();

 private:
  struct ButtonState {
    bool lastRawPressed = false;
    bool stablePressed = false;
    bool longPressSent = false;
    uint32_t rawChangedAt = 0;
    uint32_t pressedAt = 0;
  };

  ButtonState states_[BUTTON_COUNT];
};

#pragma once

#include <Arduino.h>

enum class RotaryButtonEvent : uint8_t {
  NONE,
  SHORT_PRESS,
  LONG_PRESS,
  VERY_LONG_PRESS,
};

class RotaryInput {
 public:
  void begin();
  int8_t readDetent();
  RotaryButtonEvent updateButton();

 private:
  uint8_t previousEncoderState_ = 0;
  int8_t transitionAccumulator_ = 0;

  bool lastRawButtonState_ = false;
  bool stableButtonState_ = false;
  bool longPressSent_ = false;
  bool veryLongPressSent_ = false;
  uint32_t rawButtonChangedAt_ = 0;
  uint32_t buttonPressedAt_ = 0;
};

#pragma once

#include <Arduino.h>

namespace DisplayConfig {

// Physical visible area. Rotation 1 makes the logical screen 320 x 170.
constexpr uint16_t PANEL_WIDTH = 170;
constexpr uint16_t PANEL_HEIGHT = 320;
constexpr uint8_t ROTATION = 1;

// The supplied, working yoRadio ST7789_170 version uses inversion for this
// panel. If a different batch shows negative colours, change this to false.
constexpr bool INVERT_COLORS = true;

// AO3401A is a P-channel MOSFET in the usual high-side backlight circuit:
// LOW turns the light on, so the PWM output has to be inverted.
constexpr bool BACKLIGHT_ACTIVE_LOW = true;
constexpr uint8_t BACKLIGHT_LEVELS = 15;
constexpr uint8_t DEFAULT_BACKLIGHT_LEVEL = 10;
constexpr uint32_t BACKLIGHT_PWM_FREQUENCY = 5000;
constexpr uint8_t BACKLIGHT_PWM_RESOLUTION = 8;
constexpr uint8_t BACKLIGHT_PWM_CHANNEL = 7;

}  // namespace DisplayConfig


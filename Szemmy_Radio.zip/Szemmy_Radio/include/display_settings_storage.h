#pragma once

#include <Arduino.h>
#include <Preferences.h>

#include "display_config.h"

struct DisplaySettingsData {
  uint8_t brightness = DisplayConfig::DEFAULT_BACKLIGHT_LEVEL;
  bool flipped = false;
};

class DisplaySettingsStorage {
 public:
  bool begin();
  bool load(DisplaySettingsData &settings);
  bool save(const DisplaySettingsData &settings);

 private:
  Preferences preferences_;
  bool available_ = false;
};

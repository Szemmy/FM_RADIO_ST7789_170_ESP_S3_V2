#include "preset_buttons.h"

#include "hardware_pins.h"

namespace {

constexpr uint32_t DEBOUNCE_MS = 30;
constexpr bool ACTIVE_LOW = true;

constexpr uint8_t BUTTON_PINS[PresetButtons::BUTTON_COUNT] = {
    Pins::BUTTON_1, Pins::BUTTON_2, Pins::BUTTON_3,
    Pins::BUTTON_4, Pins::BUTTON_5, Pins::BUTTON_6,
};

bool buttonPressed(uint8_t pin) {
  const bool high = digitalRead(pin) == HIGH;
  return ACTIVE_LOW ? !high : high;
}

}  // namespace

void PresetButtons::begin() {
  const uint32_t now = millis();
  for (uint8_t index = 0; index < BUTTON_COUNT; ++index) {
    // Every station button has the requested external 10 kOhm pull-up. This
    // is especially important on GPIO35 and GPIO36, which have no internal
    // pull-up capability on the classic ESP32.
    pinMode(BUTTON_PINS[index], INPUT);
    const bool pressed = buttonPressed(BUTTON_PINS[index]);
    states_[index].lastRawPressed = pressed;
    states_[index].stablePressed = pressed;
    states_[index].rawChangedAt = now;
    states_[index].pressedAt = pressed ? now : 0;
  }
}

PresetButtonEvent PresetButtons::update() {
  const uint32_t now = millis();
  PresetButtonEvent pendingEvent;

  for (uint8_t index = 0; index < BUTTON_COUNT; ++index) {
    ButtonState &state = states_[index];
    const bool rawPressed = buttonPressed(BUTTON_PINS[index]);

    if (rawPressed != state.lastRawPressed) {
      state.lastRawPressed = rawPressed;
      state.rawChangedAt = now;
    }

    if (rawPressed != state.stablePressed &&
        now - state.rawChangedAt >= DEBOUNCE_MS) {
      state.stablePressed = rawPressed;
      if (state.stablePressed) {
        state.pressedAt = now;
        state.longPressSent = false;
      } else if (!state.longPressSent &&
                 pendingEvent.type == PresetButtonEventType::NONE) {
        pendingEvent = {PresetButtonEventType::SHORT_PRESS,
                        static_cast<uint8_t>(index + 1U)};
      }
    }

    if (state.stablePressed && !state.longPressSent &&
        now - state.pressedAt >= LONG_PRESS_MS) {
      state.longPressSent = true;
      if (pendingEvent.type == PresetButtonEventType::NONE) {
        pendingEvent = {PresetButtonEventType::LONG_PRESS,
                        static_cast<uint8_t>(index + 1U)};
      }
    }
  }

  return pendingEvent;
}

#include "ir_settings_storage.h"

namespace {

constexpr uint8_t IR_STORAGE_VERSION = 1U;

struct StoredIrCode {
  uint8_t version = IR_STORAGE_VERSION;
  int16_t protocol = -1;
  uint16_t bits = 0;
  uint64_t value = 0;
  uint32_t address = 0;
  uint32_t command = 0;
};

void buildIrKey(char *key, size_t capacity, uint8_t action) {
  snprintf(key, capacity, "code%u", action);
}

}  // namespace

bool IrSettingsStorage::begin() {
  available_ = preferences_.begin("szemmy_ir", false);
  return available_;
}

bool IrSettingsStorage::load(uint8_t action, IrCodeData &code) {
  code = {};
  if (!available_ || action >= ACTION_COUNT) {
    return false;
  }

  char key[8] = {};
  buildIrKey(key, sizeof(key), action);
  if (preferences_.getBytesLength(key) != sizeof(StoredIrCode)) {
    return false;
  }

  StoredIrCode stored;
  if (preferences_.getBytes(key, &stored, sizeof(stored)) != sizeof(stored) ||
      stored.version != IR_STORAGE_VERSION || stored.bits == 0U) {
    return false;
  }

  code.valid = true;
  code.protocol = stored.protocol;
  code.bits = stored.bits;
  code.value = stored.value;
  code.address = stored.address;
  code.command = stored.command;
  return true;
}

bool IrSettingsStorage::save(uint8_t action, const IrCodeData &code) {
  if (!available_ || action >= ACTION_COUNT || !code.valid ||
      code.bits == 0U) {
    return false;
  }

  StoredIrCode stored;
  stored.protocol = code.protocol;
  stored.bits = code.bits;
  stored.value = code.value;
  stored.address = code.address;
  stored.command = code.command;

  char key[8] = {};
  buildIrKey(key, sizeof(key), action);
  return preferences_.putBytes(key, &stored, sizeof(stored)) ==
         sizeof(stored);
}

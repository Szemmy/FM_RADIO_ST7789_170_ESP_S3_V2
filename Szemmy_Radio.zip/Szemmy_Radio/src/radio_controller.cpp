#include "radio_controller.h"

#include <cstring>

namespace {

bool copyCleanRdsText(const char *source, char *target, size_t capacity,
                      bool rejectShorterText = false) {
  if (source == nullptr || capacity < 2U || capacity > 65U) {
    return false;
  }

  char cleaned[65] = {};
  size_t length = 0;
  for (size_t index = 0; index + 1U < capacity && source[index] != '\0';
       ++index) {
    const uint8_t value = static_cast<uint8_t>(source[index]);
    if (value == 0x0DU) {
      break;
    }
    // The built-in display font is ASCII. Extended RDS characters will be
    // handled later with the supplied Hungarian font set; for now replace
    // them with a readable separator instead of sending invalid glyphs.
    cleaned[length++] = value >= 32U && value <= 126U ? source[index] : ' ';
  }

  while (length > 0U && cleaned[length - 1U] == ' ') {
    --length;
  }

  size_t first = 0;
  while (first < length && cleaned[first] == ' ') {
    ++first;
  }

  if (first >= length) {
    return false;
  }

  const size_t finalLength = length - first;
  if (rejectShorterText && target[0] != '\0' &&
      finalLength < strlen(target)) {
    return false;
  }
  if (first > 0U) {
    memmove(cleaned, cleaned + first, finalLength);
  }
  cleaned[finalLength] = '\0';

  if (strncmp(target, cleaned, capacity) == 0) {
    return false;
  }

  strncpy(target, cleaned, capacity - 1U);
  target[capacity - 1U] = '\0';
  return true;
}

}  // namespace

bool RadioController::begin(bool deviceDetected, uint16_t initialFrequency) {
  initialFrequency = constrain(initialFrequency, MIN_FREQUENCY, MAX_FREQUENCY);
  frequency_ = MIN_FREQUENCY +
               ((initialFrequency - MIN_FREQUENCY) / FREQUENCY_STEP) *
                   FREQUENCY_STEP;
  available_ = deviceDetected;
  if (!available_) {
    return false;
  }

  receiver_.setup();
  receiver_.setBand(RDA_FM_BAND_USA_EU);
  receiver_.setStep(100);
  receiver_.setFmDeemphasis(1);  // Europe: 50 microseconds.
  receiver_.setSoftmute(true);
  receiver_.setSoftBlendEnable(true);
  receiver_.setMono(false);  // Allow automatic stereo reception.
  receiver_.setRDS(true);
  receiver_.clearRdsBuffer();

  // This radio drives an external amplifier. Start directly on the requested
  // stored station at the lowest audible hardware volume, with sound enabled.
  receiver_.setVolume(volume_);
  receiver_.setFrequency(frequency_);
  muted_ = false;
  receiver_.setMute(false);
  refreshReceptionStatus();
  return true;
}

void RadioController::tuneSteps(int8_t steps) {
  if (!available_ || steps == 0) {
    return;
  }

  int32_t requested = static_cast<int32_t>(frequency_) +
                      static_cast<int32_t>(steps) * FREQUENCY_STEP;
  if (requested > MAX_FREQUENCY) {
    requested = MIN_FREQUENCY;
  } else if (requested < MIN_FREQUENCY) {
    requested = MAX_FREQUENCY;
  }

  setFrequency(static_cast<uint16_t>(requested));
}

void RadioController::setFrequency(uint16_t frequency) {
  if (!available_) {
    return;
  }

  frequency = constrain(frequency, MIN_FREQUENCY, MAX_FREQUENCY);
  // Every valid stored frequency uses the configured 100 kHz raster.
  frequency = MIN_FREQUENCY +
              ((frequency - MIN_FREQUENCY) / FREQUENCY_STEP) * FREQUENCY_STEP;
  frequency_ = frequency;
  clearRdsData();
  receiver_.setFrequency(frequency_);
  refreshReceptionStatus();
}

void RadioController::changeVolume(int8_t steps) {
  if (!available_ || steps == 0) {
    return;
  }

  const int16_t requested = constrain(
      static_cast<int16_t>(volume_) + steps, static_cast<int16_t>(0),
      static_cast<int16_t>(MAX_VOLUME));
  volume_ = static_cast<uint8_t>(requested);
  receiver_.setVolume(volume_);
}

void RadioController::toggleMute() {
  if (!available_) {
    return;
  }

  setMuted(!muted_);
}

void RadioController::setMuted(bool muted) {
  if (!available_) {
    return;
  }

  muted_ = muted;
  receiver_.setMute(muted_);
}

void RadioController::refreshReceptionStatus() {
  if (!available_) {
    return;
  }

  rssi_ = static_cast<uint8_t>(constrain(receiver_.getRssi(), 0, 63));
  stationValid_ = receiver_.isFmTrue();
  stereo_ = receiver_.isStereo();
}

bool RadioController::pollRds() {
  if (!available_) {
    return false;
  }

  const bool ready = receiver_.getRdsReady();
  // RDSR only announces that a fresh group is available; it naturally goes
  // low between groups. RDSS is the persistent decoder-synchronization flag,
  // so use that for the on-screen RDS status to avoid visible OK/-- flicker.
  const bool synchronized = receiver_.getRdsSync();
  bool changed = synchronized != rdsSynchronized_;
  rdsSynchronized_ = synchronized;

  if (!ready || !receiver_.hasRdsInfo()) {
    return changed;
  }

  const uint16_t groupType = receiver_.getRdsGroupType();
  if (groupType == 2U && receiver_.isNewRdsFlagAB()) {
    // A/B changes when the station starts sending a new RadioText message.
    receiver_.clearRdsBuffer();
    if (rdsProgramText_[0] != '\0') {
      rdsProgramText_[0] = '\0';
      ++rdsRevision_;
      changed = true;
    }
  }

  char *stationName = receiver_.getRdsStationName();
  if (copyCleanRdsText(stationName, rdsStationName_,
                       sizeof(rdsStationName_), true)) {
    ++rdsRevision_;
    changed = true;
  }

  char *programText = receiver_.getRdsProgramInformation();
  if (programText == nullptr) {
    programText = receiver_.getRdsStationInformation();
  }
  if (copyCleanRdsText(programText, rdsProgramText_,
                       sizeof(rdsProgramText_))) {
    ++rdsRevision_;
    changed = true;
  }

  return changed;
}

void RadioController::clearRdsData() {
  if (available_) {
    receiver_.clearRdsBuffer();
  }
  rdsStationName_[0] = '\0';
  rdsProgramText_[0] = '\0';
  rdsSynchronized_ = false;
  ++rdsRevision_;
}

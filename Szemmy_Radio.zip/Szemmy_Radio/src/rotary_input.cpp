#include "rotary_input.h"

#include "control_config.h"
#include "hardware_pins.h"

namespace {

bool inputIsActive(uint8_t pin) {
  const bool high = digitalRead(pin) == HIGH;
  return ControlConfig::ACTIVE_LOW ? !high : high;
}

uint8_t readEncoderState() {
  return (static_cast<uint8_t>(digitalRead(Pins::ENCODER_S1)) << 1U) |
         static_cast<uint8_t>(digitalRead(Pins::ENCODER_S2));
}

}  // namespace

void RotaryInput::begin() {
  const uint8_t pinModeValue =
      ControlConfig::USE_INTERNAL_PULLUPS ? INPUT_PULLUP : INPUT;
  pinMode(Pins::ENCODER_S1, pinModeValue);
  pinMode(Pins::ENCODER_S2, pinModeValue);
  pinMode(Pins::ENCODER_KEY, pinModeValue);

  previousEncoderState_ = readEncoderState();
  lastRawButtonState_ = inputIsActive(Pins::ENCODER_KEY);
  stableButtonState_ = lastRawButtonState_;
  rawButtonChangedAt_ = millis();
  if (stableButtonState_) {
    buttonPressedAt_ = rawButtonChangedAt_;
  }
}

int8_t RotaryInput::readDetent() {
  // Valid quadrature transitions add or subtract one. Invalid jumps and
  // contact bounce add zero, so one complete detent is reported only after
  // all four expected transitions have arrived.
  static constexpr int8_t transitionTable[16] = {
      0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0,
  };

  const uint8_t currentState = readEncoderState();
  if (currentState == previousEncoderState_) {
    return 0;
  }

  const uint8_t transition = (previousEncoderState_ << 2U) | currentState;
  previousEncoderState_ = currentState;
  transitionAccumulator_ += transitionTable[transition];

  int8_t result = 0;
  if (transitionAccumulator_ >=
      ControlConfig::QUADRATURE_TRANSITIONS_PER_DETENT) {
    transitionAccumulator_ = 0;
    result = 1;
  } else if (transitionAccumulator_ <=
             -static_cast<int8_t>(
                 ControlConfig::QUADRATURE_TRANSITIONS_PER_DETENT)) {
    transitionAccumulator_ = 0;
    result = -1;
  }

  return ControlConfig::ENCODER_REVERSED ? -result : result;
}

RotaryButtonEvent RotaryInput::updateButton() {
  const uint32_t now = millis();
  const bool rawButtonState = inputIsActive(Pins::ENCODER_KEY);

  if (rawButtonState != lastRawButtonState_) {
    lastRawButtonState_ = rawButtonState;
    rawButtonChangedAt_ = now;
  }

  if (rawButtonState != stableButtonState_ &&
      now - rawButtonChangedAt_ >= ControlConfig::BUTTON_DEBOUNCE_MS) {
    stableButtonState_ = rawButtonState;

    if (stableButtonState_) {
      buttonPressedAt_ = now;
      longPressSent_ = false;
      veryLongPressSent_ = false;
    } else if (!longPressSent_) {
      return RotaryButtonEvent::SHORT_PRESS;
    }
  }

  if (stableButtonState_ && !veryLongPressSent_ &&
      now - buttonPressedAt_ >= ControlConfig::BUTTON_VERY_LONG_PRESS_MS) {
    veryLongPressSent_ = true;
    return RotaryButtonEvent::VERY_LONG_PRESS;
  }

  if (stableButtonState_ && !longPressSent_ &&
      now - buttonPressedAt_ >= ControlConfig::BUTTON_LONG_PRESS_MS) {
    longPressSent_ = true;
    return RotaryButtonEvent::LONG_PRESS;
  }

  return RotaryButtonEvent::NONE;
}

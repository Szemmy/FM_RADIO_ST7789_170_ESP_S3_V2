#include "display_settings_storage.h"

bool DisplaySettingsStorage::begin() {
  available_ = preferences_.begin("szemmy_disp", false);
  return available_;
}

bool DisplaySettingsStorage::load(DisplaySettingsData &settings) {
  settings = {};
  if (!available_) {
    return false;
  }

  settings.brightness = preferences_.getUChar(
      "brightness", DisplayConfig::DEFAULT_BACKLIGHT_LEVEL);
  if (settings.brightness < 1U ||
      settings.brightness > DisplayConfig::BACKLIGHT_LEVELS) {
    settings.brightness = DisplayConfig::DEFAULT_BACKLIGHT_LEVEL;
  }
  settings.flipped = preferences_.getBool("flipped", false);
  return true;
}

bool DisplaySettingsStorage::save(const DisplaySettingsData &settings) {
  if (!available_ || settings.brightness < 1U ||
      settings.brightness > DisplayConfig::BACKLIGHT_LEVELS) {
    return false;
  }

  const size_t brightnessBytes =
      preferences_.putUChar("brightness", settings.brightness);
  const size_t flipBytes = preferences_.putBool("flipped", settings.flipped);
  return brightnessBytes == sizeof(uint8_t) && flipBytes == sizeof(bool);
}

#include "preset_storage.h"

#include <cstring>

namespace {

void buildKey(char *key, size_t capacity, uint8_t slot, char suffix) {
  snprintf(key, capacity, "mem%u%c", slot, suffix);
}

}  // namespace

bool PresetStorage::begin() {
  available_ = preferences_.begin("szemmy_radio", false);
  return available_;
}

bool PresetStorage::load(uint8_t slot, PresetData &preset) {
  preset = {};
  if (!available_ || slot < 1U || slot > CHANNEL_COUNT) {
    return false;
  }

  char frequencyKey[12];
  char nameKey[12];
  buildKey(frequencyKey, sizeof(frequencyKey), slot, 'f');
  buildKey(nameKey, sizeof(nameKey), slot, 'n');

  const uint16_t frequency = preferences_.getUShort(frequencyKey, 0);
  if (frequency < 8750U || frequency > 10800U) {
    return false;
  }

  const String storedName = preferences_.getString(nameKey, "");
  preset.valid = true;
  preset.frequency = frequency;
  strncpy(preset.stationName, storedName.c_str(),
          sizeof(preset.stationName) - 1U);
  preset.stationName[sizeof(preset.stationName) - 1U] = '\0';
  return true;
}

bool PresetStorage::save(uint8_t slot, uint16_t frequency,
                         const char *stationName) {
  if (!available_ || slot < 1U || slot > CHANNEL_COUNT ||
      frequency < 8750U || frequency > 10800U) {
    return false;
  }

  char frequencyKey[12];
  char nameKey[12];
  char safeName[9] = {};
  buildKey(frequencyKey, sizeof(frequencyKey), slot, 'f');
  buildKey(nameKey, sizeof(nameKey), slot, 'n');
  if (stationName != nullptr) {
    strncpy(safeName, stationName, sizeof(safeName) - 1U);
  }

  const size_t frequencyBytes = preferences_.putUShort(frequencyKey, frequency);
  preferences_.putString(nameKey, safeName);
  return frequencyBytes == sizeof(uint16_t);
}

bool PresetStorage::clear(uint8_t slot) {
  if (!available_ || slot < 1U || slot > CHANNEL_COUNT) {
    return false;
  }

  char frequencyKey[12];
  char nameKey[12];
  buildKey(frequencyKey, sizeof(frequencyKey), slot, 'f');
  buildKey(nameKey, sizeof(nameKey), slot, 'n');
  const size_t frequencyBytes = preferences_.putUShort(frequencyKey, 0U);
  preferences_.remove(nameKey);
  return frequencyBytes == sizeof(uint16_t);
}

uint8_t PresetStorage::loadLastChannel() {
  if (!available_) {
    return 0U;
  }
  const uint8_t slot = preferences_.getUChar("lastch", 0U);
  return slot >= 1U && slot <= CHANNEL_COUNT ? slot : 0U;
}

bool PresetStorage::saveLastChannel(uint8_t slot) {
  if (!available_ || slot < 1U || slot > CHANNEL_COUNT) {
    return false;
  }
  if (preferences_.getUChar("lastch", 0U) == slot) {
    return true;
  }
  return preferences_.putUChar("lastch", slot) == sizeof(uint8_t);
}

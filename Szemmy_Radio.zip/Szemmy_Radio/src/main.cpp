#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <RTClib.h>
#include <esp_arduino_version.h>
#include <esp_sleep.h>
#include <cstring>

#include "IRremoteESP8266/IRrecv.h"
#include "IRremoteESP8266/IRremoteESP8266.h"

#include "display_config.h"
#include "display_settings_storage.h"
#include "hardware_pins.h"
#include "ir_settings_storage.h"
#include "preset_buttons.h"
#include "preset_storage.h"
#include "radio_controller.h"
#include "rotary_input.h"
#include "szemmy_logo.h"

namespace {

SPIClass displaySpi(VSPI);
Adafruit_ST7789 display(&displaySpi, Pins::TFT_CS, Pins::TFT_DC, Pins::TFT_RST);
RTC_DS3231 rtc;
RadioController radio;
RotaryInput rotary;
PresetButtons presetButtons;
PresetStorage presetStorage;
DisplaySettingsStorage displaySettingsStorage;
IrSettingsStorage irSettingsStorage;
IRrecv irReceiver(Pins::IR_INPUT);
decode_results irDecodeResults;
PresetData presets[PresetStorage::CHANNEL_COUNT];
DisplaySettingsData displaySettings;
DisplaySettingsData displayEdit;

// The clock is rendered off-screen first and then copied to the ST7789 in one
// operation. This keeps the one-second refresh completely flicker-free.
constexpr int16_t CLOCK_CANVAS_WIDTH = 144;
constexpr int16_t CLOCK_CANVAS_HEIGHT = 24;
constexpr int16_t CLOCK_X = 168;
constexpr int16_t CLOCK_Y = 117;
GFXcanvas16 clockCanvas(CLOCK_CANVAS_WIDTH, CLOCK_CANVAS_HEIGHT);

// The changing part of the automatic-search screen is also rendered in RAM.
// The finished frame is copied to the ST7789 in one operation, so the user
// never sees the black clearing rectangles between two frequency steps.
constexpr int16_t AUTO_SCAN_CANVAS_X = 7;
constexpr int16_t AUTO_SCAN_CANVAS_Y = 31;
constexpr int16_t AUTO_SCAN_CANVAS_WIDTH = 306;
constexpr int16_t AUTO_SCAN_CANVAS_HEIGHT = 113;
GFXcanvas16 autoScanCanvas(AUTO_SCAN_CANVAS_WIDTH, AUTO_SCAN_CANVAS_HEIGHT);

// The large FM frequency shares the lower information row with the clock.
// It is redrawn only when tuning changes, so it does not need a frame buffer.
constexpr int16_t FREQUENCY_X = 8;
constexpr int16_t FREQUENCY_Y = 117;
constexpr int16_t FREQUENCY_WIDTH = 154;
constexpr int16_t FREQUENCY_HEIGHT = 25;

// The old one-line button-help area is deliberately left out of the radio
// screen.  Its room is used for the larger date, temperature, frequency and
// clock.  Short-lived notices use the control-mode row instead.
constexpr int16_t CONTROL_ROW_Y = 147;
constexpr int16_t CONTROL_ROW_HEIGHT = 20;

uint8_t currentBacklightLevel = 0;
bool rtcAvailable = false;
bool rtcWasAdjusted = false;
bool rda5807Available = false;
bool rtcEepromAvailable = false;
bool presetStorageAvailable = false;
bool displaySettingsStorageAvailable = false;
bool irSettingsStorageAvailable = false;
uint8_t activePreset = 0;
bool transientMessageActive = false;
uint32_t transientMessageUntil = 0;

constexpr uint32_t MENU_TIMEOUT_MS = 5000U;
constexpr uint32_t MENU_BLINK_MS = 350U;
constexpr uint32_t IR_MENU_TIMEOUT_MS = 30000U;
constexpr uint32_t IR_LEARN_CONFIRM_MS = 1000U;
constexpr uint32_t IR_WAKE_SUPPRESS_MS = 600U;
constexpr uint32_t IR_CHANNEL_ENTRY_TIMEOUT_MS = 5000U;
constexpr uint32_t IR_SEEK_SETTLE_MS = 120U;
constexpr uint16_t IR_SEEK_MAX_STEPS =
    (RadioController::MAX_FREQUENCY - RadioController::MIN_FREQUENCY) /
    RadioController::FREQUENCY_STEP;
constexpr uint16_t EDIT_YEAR_MIN = 2020U;
constexpr uint16_t EDIT_YEAR_MAX = 2099U;
constexpr uint32_t AUTO_SCAN_SETTLE_MS = 110U;
constexpr uint32_t AUTO_SCAN_RDS_WAIT_MS = 1800U;
constexpr uint32_t AUTO_SCAN_RDS_POLL_MS = 35U;
constexpr uint32_t AUTO_SCAN_RDS_STABLE_MS = 350U;
constexpr uint32_t AUTO_SCAN_RESULT_MS = 2600U;
constexpr uint32_t AUTO_SCAN_DISPLAY_INTERVAL_MS = 250U;
constexpr uint8_t AUTO_SCAN_MIN_RSSI = 10U;
constexpr uint8_t CHANNEL_MENU_ITEM_COUNT =
    PresetStorage::CHANNEL_COUNT + 1U;  // Automatic scan + 30 memories.

constexpr uint8_t DS3231_ADDRESS = 0x68;
constexpr uint8_t RDA5807_SEQUENTIAL_ADDRESS = 0x10;
constexpr uint8_t RDA5807_RANDOM_ADDRESS = 0x11;
constexpr uint8_t RTC_EEPROM_ADDRESS = 0x57;

const char *const HUNGARIAN_MONTHS[] = {
    "JANUAR",    "FEBRUAR", "MARCIUS",   "APRILIS",
    "MAJUS",     "JUNIUS",  "JULIUS",    "AUGUSZTUS",
    "SZEPTEMBER", "OKTOBER", "NOVEMBER", "DECEMBER",
};

// Private single-byte codes used only in stored station names. The built-in
// Adafruit 5x7 font has no complete Hungarian alphabet, so these 18 glyphs are
// rendered by the small bitmap table below.
constexpr uint8_t HU_LOWER_A_ACUTE = 0xE0;
constexpr uint8_t HU_LOWER_E_ACUTE = 0xE1;
constexpr uint8_t HU_LOWER_I_ACUTE = 0xE2;
constexpr uint8_t HU_LOWER_O_ACUTE = 0xE3;
constexpr uint8_t HU_LOWER_O_UMLAUT = 0xE4;
constexpr uint8_t HU_LOWER_O_DOUBLE_ACUTE = 0xE5;
constexpr uint8_t HU_LOWER_U_ACUTE = 0xE6;
constexpr uint8_t HU_LOWER_U_UMLAUT = 0xE7;
constexpr uint8_t HU_LOWER_U_DOUBLE_ACUTE = 0xE8;
constexpr uint8_t HU_UPPER_A_ACUTE = 0xE9;
constexpr uint8_t HU_UPPER_E_ACUTE = 0xEA;
constexpr uint8_t HU_UPPER_I_ACUTE = 0xEB;
constexpr uint8_t HU_UPPER_O_ACUTE = 0xEC;
constexpr uint8_t HU_UPPER_O_UMLAUT = 0xED;
constexpr uint8_t HU_UPPER_O_DOUBLE_ACUTE = 0xEE;
constexpr uint8_t HU_UPPER_U_ACUTE = 0xEF;
constexpr uint8_t HU_UPPER_U_UMLAUT = 0xF0;
constexpr uint8_t HU_UPPER_U_DOUBLE_ACUTE = 0xF1;
constexpr uint8_t HU_GLYPH_FIRST = HU_LOWER_A_ACUTE;
constexpr uint8_t HU_GLYPH_LAST = HU_UPPER_U_DOUBLE_ACUTE;

const uint8_t HUNGARIAN_GLYPHS[][7] PROGMEM = {
    {0x04, 0x02, 0x0E, 0x01, 0x0F, 0x11, 0x0F},  // á
    {0x04, 0x02, 0x0E, 0x11, 0x1F, 0x10, 0x0E},  // é
    {0x04, 0x02, 0x0C, 0x04, 0x04, 0x04, 0x0E},  // í
    {0x04, 0x02, 0x0E, 0x11, 0x11, 0x11, 0x0E},  // ó
    {0x0A, 0x00, 0x0E, 0x11, 0x11, 0x11, 0x0E},  // ö
    {0x0A, 0x14, 0x0E, 0x11, 0x11, 0x11, 0x0E},  // ő
    {0x04, 0x02, 0x11, 0x11, 0x11, 0x13, 0x0D},  // ú
    {0x0A, 0x00, 0x11, 0x11, 0x11, 0x13, 0x0D},  // ü
    {0x0A, 0x14, 0x11, 0x11, 0x11, 0x13, 0x0D},  // ű
    {0x04, 0x02, 0x0E, 0x11, 0x1F, 0x11, 0x11},  // Á
    {0x04, 0x02, 0x1F, 0x10, 0x1E, 0x10, 0x1F},  // É
    {0x04, 0x02, 0x1F, 0x04, 0x04, 0x04, 0x1F},  // Í
    {0x04, 0x02, 0x0E, 0x11, 0x11, 0x11, 0x0E},  // Ó
    {0x0A, 0x00, 0x0E, 0x11, 0x11, 0x11, 0x0E},  // Ö
    {0x0A, 0x14, 0x0E, 0x11, 0x11, 0x11, 0x0E},  // Ő
    {0x04, 0x02, 0x11, 0x11, 0x11, 0x11, 0x0E},  // Ú
    {0x0A, 0x00, 0x11, 0x11, 0x11, 0x11, 0x0E},  // Ü
    {0x0A, 0x14, 0x11, 0x11, 0x11, 0x11, 0x0E},  // Ű
};

enum class ControlMode : uint8_t {
  VOLUME,
  TUNING,
};

enum class UiScreen : uint8_t {
  RADIO,
  MAIN_MENU,
  CLOCK_EDITOR,
  DISPLAY_EDITOR,
  CHANNEL_LIST,
  CHANNEL_NAME_EDITOR,
  AUTO_SCAN,
  IR_LEARNING,
};

enum class IrAction : uint8_t {
  CHANNEL_UP,
  CHANNEL_DOWN,
  VOLUME_UP,
  VOLUME_DOWN,
  MUTE,
  POWER,
  SEEK_UP,
  SEEK_DOWN,
  DIGIT_0,
  DIGIT_1,
  DIGIT_2,
  DIGIT_3,
  DIGIT_4,
  DIGIT_5,
  DIGIT_6,
  DIGIT_7,
  DIGIT_8,
  DIGIT_9,
  CONFIRM,
  COUNT,
};

static_assert(static_cast<uint8_t>(IrAction::COUNT) ==
                  IrSettingsStorage::ACTION_COUNT,
              "IR action and storage counts must match");

enum class KeyboardPage : uint8_t {
  LOWERCASE,
  UPPERCASE,
  HUNGARIAN,
  SYMBOLS,
};

enum class KeyboardAction : uint8_t {
  CHARACTER,
  BACKSPACE,
  SPACE,
  LOWERCASE,
  UPPERCASE,
  HUNGARIAN,
  SYMBOLS,
  DONE,
};

struct KeyboardKey {
  KeyboardAction action = KeyboardAction::CHARACTER;
  uint8_t character = 0;
  const char *label = "";
};

enum class AutoScanPhase : uint8_t {
  IDLE,
  SETTLING,
  RDS_WAIT,
  COMPLETE,
};

enum class IrSeekPhase : uint8_t {
  IDLE,
  SETTLING,
};

enum class MainMenuItem : uint8_t {
  CLOCK_DATE,
  DISPLAY_SETTINGS,
  CHANNELS,
  INFRARED,
  MUTE,
  EXIT,
  COUNT,
};

struct ClockEditValues {
  uint16_t year = 2026;
  uint8_t month = 1;
  uint8_t day = 1;
  uint8_t hour = 0;
  uint8_t minute = 0;
  uint8_t second = 0;
};

ControlMode controlMode = ControlMode::VOLUME;
UiScreen uiScreen = UiScreen::RADIO;
uint8_t mainMenuSelection = 0;
uint8_t clockFieldSelection = 0;
bool clockFieldEditing = false;
bool clockFieldVisible = true;
bool clockEditChanged = false;
ClockEditValues clockEdit;
uint8_t displayFieldSelection = 0;
bool displayFieldEditing = false;
bool displayFieldVisible = true;
bool displayEditChanged = false;
uint8_t channelSelection = 0;
uint8_t channelWindowStart = 0;
uint8_t channelNameEditSlot = 0;
char channelNameEdit[sizeof(PresetData::stationName)] = {};
uint8_t keyboardSelection = 0;
KeyboardPage keyboardPage = KeyboardPage::LOWERCASE;
PresetData autoScanResults[PresetStorage::CHANNEL_COUNT];
AutoScanPhase autoScanPhase = AutoScanPhase::IDLE;
uint8_t autoScanCount = 0;
uint16_t autoScanFrequency = RadioController::MIN_FREQUENCY;
uint16_t autoScanOriginalFrequency = 0;
uint8_t autoScanOriginalPreset = 0;
bool autoScanOriginalMuted = true;
bool autoScanSaveSucceeded = true;
uint32_t autoScanPhaseStarted = 0;
uint32_t autoScanLastRdsPoll = 0;
uint32_t autoScanRdsStableSince = 0;
uint32_t autoScanLastDisplay = 0;
char autoScanRdsCandidate[9] = {};
uint32_t menuLastActivity = 0;
uint32_t menuLastBlink = 0;
bool menuNoticeActive = false;
uint32_t menuNoticeUntil = 0;
IrCodeData irCodes[IrSettingsStorage::ACTION_COUNT];
uint8_t irLearningSelection = 0;
bool irLearningAdvancePending = false;
uint32_t irLearningAdvanceAt = 0;
bool irLearningDuplicateNotice = false;
uint32_t irLearningDuplicateUntil = 0;
IrCodeData lastIrSignal;
uint32_t lastIrSignalAt = 0;
uint32_t lastIrActionAt[IrSettingsStorage::ACTION_COUNT] = {};
uint32_t irSuppressUntil = 0;
uint8_t irChannelEntryValue = 0U;
uint8_t irChannelEntryDigits = 0U;
uint32_t irChannelEntryLastAt = 0U;
IrSeekPhase irSeekPhase = IrSeekPhase::IDLE;
int8_t irSeekDirection = 1;
uint16_t irSeekOriginalFrequency = 0U;
uint8_t irSeekOriginalPreset = 0U;
bool irSeekOriginalMuted = false;
uint16_t irSeekStepsChecked = 0U;
uint32_t irSeekStepStarted = 0U;

void updateRtcDisplay(bool force);
void recallStoredStation(uint8_t slot);
void redrawRadioScreen();
void drawControlMode();
void startAutoScan();
void cancelAutoScan();
void enterIrLearning();
void processInfrared();
void startIrSeek(int8_t direction);
void updateIrSeek();
void cancelIrSeek(bool showMessage = true);

uint8_t backlightPwmValue(uint8_t level) {
  level = constrain(level, 0, DisplayConfig::BACKLIGHT_LEVELS);
  const uint16_t lightDuty =
      (static_cast<uint16_t>(level) * 255U) / DisplayConfig::BACKLIGHT_LEVELS;
  return DisplayConfig::BACKLIGHT_ACTIVE_LOW ? 255U - lightDuty : lightDuty;
}

void writeBacklightPwm(uint8_t value) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(Pins::TFT_BACKLIGHT, value);
#else
  ledcWrite(DisplayConfig::BACKLIGHT_PWM_CHANNEL, value);
#endif
}

void beginBacklight() {
  // Keep the P-channel MOSFET off while PWM is being configured.
  pinMode(Pins::TFT_BACKLIGHT, OUTPUT);
  digitalWrite(Pins::TFT_BACKLIGHT,
               DisplayConfig::BACKLIGHT_ACTIVE_LOW ? HIGH : LOW);

#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(Pins::TFT_BACKLIGHT, DisplayConfig::BACKLIGHT_PWM_FREQUENCY,
             DisplayConfig::BACKLIGHT_PWM_RESOLUTION);
#else
  ledcSetup(DisplayConfig::BACKLIGHT_PWM_CHANNEL,
            DisplayConfig::BACKLIGHT_PWM_FREQUENCY,
            DisplayConfig::BACKLIGHT_PWM_RESOLUTION);
  ledcAttachPin(Pins::TFT_BACKLIGHT, DisplayConfig::BACKLIGHT_PWM_CHANNEL);
#endif

  writeBacklightPwm(backlightPwmValue(0));
}

void setBacklightLevel(uint8_t level) {
  currentBacklightLevel =
      constrain(level, 0, DisplayConfig::BACKLIGHT_LEVELS);
  writeBacklightPwm(backlightPwmValue(currentBacklightLevel));
}

uint8_t displayRotation(bool flipped) {
  return static_cast<uint8_t>(
      (DisplayConfig::ROTATION + (flipped ? 2U : 0U)) & 0x03U);
}

void loadDisplaySettings() {
  displaySettingsStorageAvailable = displaySettingsStorage.begin();
  if (!displaySettingsStorageAvailable ||
      !displaySettingsStorage.load(displaySettings)) {
    displaySettings = {};
  }
  displayEdit = displaySettings;

  Serial.printf("Display settings: %s, brightness %u/%u, flip %s\n",
                displaySettingsStorageAvailable ? "OK" : "not available",
                displaySettings.brightness, DisplayConfig::BACKLIGHT_LEVELS,
                displaySettings.flipped ? "ON" : "OFF");
}

void loadIrSettings() {
  irSettingsStorageAvailable = irSettingsStorage.begin();
  uint8_t learnedCount = 0U;
  for (uint8_t action = 0; action < IrSettingsStorage::ACTION_COUNT;
       ++action) {
    if (irSettingsStorageAvailable &&
        irSettingsStorage.load(action, irCodes[action])) {
      ++learnedCount;
    } else {
      irCodes[action] = {};
    }
  }

  Serial.printf("IR settings: %s, %u/%u functions learned\n",
                irSettingsStorageAvailable ? "OK" : "not available",
                learnedCount, IrSettingsStorage::ACTION_COUNT);
}

bool i2cDevicePresent(uint8_t address) {
  Wire.beginTransmission(address);
  return Wire.endTransmission() == 0;
}

void scanI2cBus() {
  uint8_t devicesFound = 0;
  Serial.printf("I2C scan on SDA GPIO%u, SCL GPIO%u\n", Pins::I2C_SDA,
                Pins::I2C_SCL);

  for (uint8_t address = 1; address < 127; ++address) {
    if (i2cDevicePresent(address)) {
      Serial.printf("  device found at 0x%02X\n", address);
      ++devicesFound;
    }
  }

  if (devicesFound == 0) {
    Serial.println("  no I2C device found");
  }
}

void beginI2cDevices() {
  Wire.begin(Pins::I2C_SDA, Pins::I2C_SCL, 100000U);
  Wire.setTimeOut(50);
  scanI2cBus();

  rda5807Available =
      i2cDevicePresent(RDA5807_SEQUENTIAL_ADDRESS) ||
      i2cDevicePresent(RDA5807_RANDOM_ADDRESS);
  rtcEepromAvailable = i2cDevicePresent(RTC_EEPROM_ADDRESS);

  if (i2cDevicePresent(DS3231_ADDRESS)) {
    rtcAvailable = rtc.begin(&Wire);
    if (rtcAvailable && rtc.lostPower()) {
      rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
      rtcWasAdjusted = true;
      Serial.println("DS3231 lost power: set to firmware build time");
    }
  }

  Serial.printf("DS3231 (0x68): %s\n", rtcAvailable ? "OK" : "not found");
  Serial.printf("RDA5807 (0x10/0x11): %s\n",
                rda5807Available ? "detected" : "not found");
  Serial.printf("RTC module EEPROM (0x57): %s\n",
                rtcEepromAvailable ? "detected" : "not found/unused");
}

bool isHungarianGlyph(uint8_t character) {
  return character >= HU_GLYPH_FIRST && character <= HU_GLYPH_LAST;
}

void drawUiGlyph(Adafruit_GFX &target, int16_t x, int16_t y,
                 uint8_t character, uint16_t color, uint8_t textSize) {
  if (!isHungarianGlyph(character)) {
    target.drawChar(x, y, character, color, color, textSize);
    return;
  }

  const uint8_t glyphIndex = character - HU_GLYPH_FIRST;
  for (uint8_t row = 0; row < 7U; ++row) {
    const uint8_t rowBits = pgm_read_byte(&HUNGARIAN_GLYPHS[glyphIndex][row]);
    for (uint8_t column = 0; column < 5U; ++column) {
      if ((rowBits & (1U << (4U - column))) != 0U) {
        target.fillRect(x + static_cast<int16_t>(column) * textSize,
                        y + static_cast<int16_t>(row) * textSize, textSize,
                        textSize, color);
      }
    }
  }
}

int16_t uiTextWidth(const char *text, uint8_t textSize) {
  return text == nullptr
             ? 0
             : static_cast<int16_t>(strlen(text) * 6U * textSize);
}

void drawUiText(Adafruit_GFX &target, int16_t x, int16_t y, const char *text,
                uint16_t color, uint8_t textSize) {
  if (text == nullptr) {
    return;
  }
  while (*text != '\0') {
    drawUiGlyph(target, x, y, static_cast<uint8_t>(*text), color, textSize);
    x += 6 * textSize;
    ++text;
  }
}

void drawCenteredText(const char *text, int16_t y, uint16_t color,
                      uint8_t textSize) {
  const int16_t width = uiTextWidth(text, textSize);
  drawUiText(display, (display.width() - width) / 2, y, text, color, textSize);
}

void drawRightAlignedText(const char *text, int16_t rightX, int16_t y,
                          uint16_t color, uint8_t textSize) {
  drawUiText(display, rightX - uiTextWidth(text, textSize), y, text, color,
             textSize);
}

void drawCenteredCanvasText(GFXcanvas16 &canvas, const char *text, int16_t y,
                            uint16_t color, uint8_t textSize) {
  const int16_t width = uiTextWidth(text, textSize);
  drawUiText(canvas, (canvas.width() - width) / 2, y, text, color, textSize);
}

void drawDefaultInformationLine() {
  // No permanent button-help text on the main screen.  Restore the normal
  // control-mode row after a temporary notice disappears.
  drawControlMode();
}

void showTransientMessage(const char *message, uint16_t color,
                          uint32_t durationMs = 2400U) {
  transientMessageActive = true;
  transientMessageUntil = millis() + durationMs;
  display.fillRect(7, CONTROL_ROW_Y, display.width() - 14,
                   CONTROL_ROW_HEIGHT, ST77XX_BLACK);
  drawCenteredText(message, CONTROL_ROW_Y + 7, color, 1);
}

void updateTransientMessage() {
  if (!transientMessageActive ||
      static_cast<int32_t>(millis() - transientMessageUntil) < 0) {
    return;
  }

  transientMessageActive = false;
  drawDefaultInformationLine();
}

bool isIrDigitAction(IrAction action) {
  const uint8_t value = static_cast<uint8_t>(action);
  return value >= static_cast<uint8_t>(IrAction::DIGIT_0) &&
         value <= static_cast<uint8_t>(IrAction::DIGIT_9);
}

uint8_t irDigitValue(IrAction action) {
  return static_cast<uint8_t>(action) -
         static_cast<uint8_t>(IrAction::DIGIT_0);
}

void clearIrChannelEntry(bool restoreInformationLine = false) {
  const bool wasActive = irChannelEntryDigits != 0U;
  irChannelEntryValue = 0U;
  irChannelEntryDigits = 0U;
  irChannelEntryLastAt = 0U;

  if (restoreInformationLine && wasActive && uiScreen == UiScreen::RADIO) {
    transientMessageActive = false;
    drawDefaultInformationLine();
  }
}

void showIrChannelEntry() {
  char message[36] = {};
  snprintf(message, sizeof(message), "CSATORNA: %u  OK=BETOLT",
           irChannelEntryValue);
  showTransientMessage(message, ST77XX_YELLOW, IR_CHANNEL_ENTRY_TIMEOUT_MS);
}

void appendIrChannelDigit(uint8_t digit) {
  if (digit > 9U) {
    return;
  }

  const uint32_t now = millis();
  if (irChannelEntryDigits != 0U &&
      now - irChannelEntryLastAt >= IR_CHANNEL_ENTRY_TIMEOUT_MS) {
    clearIrChannelEntry(false);
  }

  // Only two digits are needed for the 1-30 channel range. A third digit
  // starts a fresh entry, which also provides a simple way to correct input.
  if (irChannelEntryDigits >= 2U) {
    irChannelEntryValue = digit;
    irChannelEntryDigits = 1U;
  } else {
    irChannelEntryValue =
        static_cast<uint8_t>(irChannelEntryValue * 10U + digit);
    ++irChannelEntryDigits;
  }
  irChannelEntryLastAt = now;
  showIrChannelEntry();
  Serial.printf("IR channel entry: %u\n", irChannelEntryValue);
}

void confirmIrChannelEntry() {
  const uint32_t now = millis();
  if (irChannelEntryDigits == 0U ||
      now - irChannelEntryLastAt >= IR_CHANNEL_ENTRY_TIMEOUT_MS) {
    clearIrChannelEntry(false);
    showTransientMessage("ELOSZOR IRJ BE EGY CSATORNAT", ST77XX_YELLOW,
                         2600U);
    Serial.println("IR channel entry confirm without a channel number");
    return;
  }

  const uint8_t selectedChannel = irChannelEntryValue;
  clearIrChannelEntry(false);
  if (selectedChannel < 1U ||
      selectedChannel > PresetStorage::CHANNEL_COUNT) {
    char message[36] = {};
    snprintf(message, sizeof(message), "HIBAS CSATORNA: %u  (1-%u)",
             selectedChannel, PresetStorage::CHANNEL_COUNT);
    showTransientMessage(message, ST77XX_RED, 2800U);
    Serial.printf("IR channel entry invalid: %u\n", selectedChannel);
    return;
  }

  recallStoredStation(selectedChannel);
}

void updateIrChannelEntry() {
  if (irChannelEntryDigits != 0U &&
      millis() - irChannelEntryLastAt >= IR_CHANNEL_ENTRY_TIMEOUT_MS) {
    clearIrChannelEntry(true);
    Serial.println("IR channel entry timed out");
  }
}

void drawCornerMarkers() {
  display.fillRect(1, 1, 5, 5, ST77XX_RED);
  display.fillRect(display.width() - 6, 1, 5, 5, ST77XX_GREEN);
  display.fillRect(1, display.height() - 6, 5, 5, ST77XX_BLUE);
  display.fillRect(display.width() - 6, display.height() - 6, 5, 5,
                   ST77XX_YELLOW);
}

void drawStaticRadioScreen() {
  const uint16_t cyan = display.color565(0, 220, 255);
  const uint16_t dimText = display.color565(125, 145, 160);

  display.fillScreen(ST77XX_BLACK);
  display.drawRect(0, 0, display.width(), display.height(), ST77XX_WHITE);
  drawCornerMarkers();

  drawCenteredText("SZEMMY RADIO - RDA5807", 7, cyan, 2);
  display.drawFastHLine(8, 27, display.width() - 16, cyan);
  // The divider above the frequency/clock row moves down with that row.
  display.drawFastHLine(8, 111, display.width() - 16, dimText);
}

void drawRadioFrequency() {
  display.fillRect(FREQUENCY_X, FREQUENCY_Y, FREQUENCY_WIDTH,
                   FREQUENCY_HEIGHT, ST77XX_BLACK);

  if (!radio.available()) {
    return;
  }

  char frequencyText[8];
  snprintf(frequencyText, sizeof(frequencyText), "%u.%u",
           radio.frequency() / 100U, (radio.frequency() % 100U) / 10U);
  constexpr char unitText[] = "MHz";
  constexpr int16_t unitGap = 3;
  const int16_t frequencyWidth = uiTextWidth(frequencyText, 3);
  const int16_t unitWidth = uiTextWidth(unitText, 1);
  const int16_t totalWidth = frequencyWidth + unitGap + unitWidth;
  const int16_t startX =
      FREQUENCY_X + (FREQUENCY_WIDTH - totalWidth) / 2;

  drawUiText(display, startX, FREQUENCY_Y, frequencyText, ST77XX_WHITE, 3);
  drawUiText(display, startX + frequencyWidth + unitGap, FREQUENCY_Y + 13,
             unitText, ST77XX_CYAN, 1);
}

void drawRadioReceptionStatus() {
  display.fillRect(7, 59, display.width() - 14, 10, ST77XX_BLACK);

  if (!radio.available()) {
    return;
  }

  char statusText[56];
  snprintf(statusText, sizeof(statusText), "%s RSSI:%02u FM:%s RDS:%s",
           radio.stereo() ? "SZTEREO" : "MONO", radio.rssi(),
           radio.stationValid() ? "OK" : "--",
           radio.rdsSynchronized() ? "OK" : "--");
  display.setTextColor(radio.stationValid() ? ST77XX_GREEN : ST77XX_YELLOW);
  display.setTextSize(1);
  drawCenteredText(statusText, 60,
                   radio.stationValid() ? ST77XX_GREEN : ST77XX_YELLOW, 1);
}

void drawRdsStationName() {
  display.fillRect(7, 31, display.width() - 14, 17, ST77XX_BLACK);

  if (!radio.available()) {
    drawCenteredText("RDA5807 NINCS", 32, ST77XX_RED, 2);
    return;
  }

  // RDS names are often unstable while the received signal changes.  Once a
  // station has been stored, its saved name (or the later user-edited name)
  // is the authoritative name on the radio screen.  Live RDS remains useful
  // only while manually tuning, or for a stored slot that has no name yet.
  const PresetData *storedPreset = nullptr;
  if (activePreset >= 1U && activePreset <= PresetStorage::CHANNEL_COUNT &&
      presets[activePreset - 1U].valid) {
    storedPreset = &presets[activePreset - 1U];
  }

  const char *stationName = radio.rdsStationName();
  if (storedPreset != nullptr && storedPreset->stationName[0] != '\0' &&
      strcmp(storedPreset->stationName, "N/A") != 0) {
    stationName = storedPreset->stationName;
  }

  if (stationName[0] == '\0') {
    drawUiText(display, 7 + (258 - uiTextWidth("RDS: ---", 2)) / 2, 32,
               "RDS: ---", ST77XX_YELLOW, 2);
  } else {
    // Leave a right-side column for the equally large memory label.
    const int16_t stationAreaWidth = storedPreset == nullptr ?
                                         display.width() - 14 :
                                         258;
    drawUiText(display,
               7 + (stationAreaWidth - uiTextWidth(stationName, 2)) / 2, 32,
               stationName, ST77XX_CYAN, 2);
  }

  if (storedPreset != nullptr) {
    char memoryLabel[5] = {};
    snprintf(memoryLabel, sizeof(memoryLabel), activePreset <= 6U ? "M%02u"
                                                                  : "C%02u",
             activePreset);
    drawRightAlignedText(memoryLabel, display.width() - 8, 32, ST77XX_YELLOW,
                         2);
  }
}

void drawRdsProgramText(uint16_t scrollOffset) {
  constexpr size_t visibleCharacters = 48;
  constexpr size_t scrollGap = 6;
  char visibleText[visibleCharacters + 1] = {};
  const char *programText = radio.rdsProgramText();
  const size_t length = strlen(programText);

  display.fillRect(7, 49, display.width() - 14, 9, ST77XX_BLACK);

  if (!radio.available()) {
    drawCenteredText("ELLENORIZD: SDA21 / SCL22", 50, ST77XX_YELLOW, 1);
    return;
  }

  if (length == 0U) {
    drawCenteredText("RADIOTEXT: VARAKOZAS...", 50,
                     display.color565(125, 145, 160), 1);
    return;
  }

  if (length <= visibleCharacters) {
    strncpy(visibleText, programText, visibleCharacters);
    drawCenteredText(visibleText, 50, ST77XX_WHITE, 1);
    return;
  }

  const size_t cycleLength = length + scrollGap;
  for (size_t index = 0; index < visibleCharacters; ++index) {
    const size_t sourceIndex = (scrollOffset + index) % cycleLength;
    visibleText[index] = sourceIndex < length ? programText[sourceIndex] : ' ';
  }
  visibleText[visibleCharacters] = '\0';
  display.setTextColor(ST77XX_WHITE);
  display.setTextSize(1);
  display.setCursor(16, 50);
  display.print(visibleText);
}

void drawRadioVolume() {
  display.fillRect(7, 70, display.width() - 14, 18, ST77XX_BLACK);

  if (!radio.available()) {
    return;
  }

  char volumeText[40];
  snprintf(volumeText, sizeof(volumeText), "HANGERO: %02u/%02u  [%s]",
           radio.volume(), RadioController::MAX_VOLUME,
           radio.muted() ? "NEMITVA" : "SZOL");
  drawCenteredText(volumeText, 71,
                   radio.muted() ? ST77XX_YELLOW : ST77XX_GREEN, 2);
}

void drawControlMode() {
  display.fillRect(7, CONTROL_ROW_Y, display.width() - 14, CONTROL_ROW_HEIGHT,
                   ST77XX_BLACK);

  if (!radio.available()) {
    return;
  }

  if (controlMode == ControlMode::VOLUME) {
    drawCenteredText("MOD: HANGERO  ROVID:MENU  HOSSZU:HANGOL",
                     CONTROL_ROW_Y + 7,
                     ST77XX_CYAN, 1);
  } else {
    drawCenteredText("MOD: HANGOLAS  0.1 MHz  ROVID:VISSZA",
                     CONTROL_ROW_Y + 7,
                     ST77XX_MAGENTA, 1);
  }
}

void updateRadioFields(bool force) {
  static uint16_t lastFrequency = UINT16_MAX;
  static uint8_t lastVolume = UINT8_MAX;
  static uint8_t lastRssi = UINT8_MAX;
  static bool lastMuted = false;
  static bool lastStereo = false;
  static bool lastStationValid = false;
  static bool lastRdsSynchronized = false;
  static ControlMode lastControlMode = ControlMode::TUNING;

  if (force || radio.frequency() != lastFrequency) {
    lastFrequency = radio.frequency();
    drawRadioFrequency();
  }

  if (force || radio.volume() != lastVolume || radio.muted() != lastMuted) {
    lastVolume = radio.volume();
    lastMuted = radio.muted();
    drawRadioVolume();
  }

  if (force || radio.rssi() != lastRssi || radio.stereo() != lastStereo ||
      radio.stationValid() != lastStationValid ||
      radio.rdsSynchronized() != lastRdsSynchronized) {
    lastRssi = radio.rssi();
    lastStereo = radio.stereo();
    lastStationValid = radio.stationValid();
    lastRdsSynchronized = radio.rdsSynchronized();
    drawRadioReceptionStatus();
  }

  if (force || controlMode != lastControlMode) {
    lastControlMode = controlMode;
    drawControlMode();
  }
}

void updateRdsDisplay() {
  static uint32_t lastPollTime = 0;
  static uint32_t lastScrollTime = 0;
  static uint32_t lastRevision = UINT32_MAX;
  static uint16_t scrollOffset = 0;
  const uint32_t now = millis();

  if (!radio.available()) {
    if (lastRevision == UINT32_MAX) {
      drawRdsStationName();
      drawRdsProgramText(0);
      lastRevision = 0;
    }
    return;
  }

  if (now - lastPollTime >= 50U) {
    lastPollTime = now;
    if (radio.pollRds()) {
      updateRadioFields(false);
    }
  }

  if (radio.rdsRevision() != lastRevision) {
    lastRevision = radio.rdsRevision();
    scrollOffset = 0;
    lastScrollTime = now;
    drawRdsStationName();
    drawRdsProgramText(scrollOffset);

    if (radio.rdsStationName()[0] != '\0') {
      Serial.printf("RDS station: %s\n", radio.rdsStationName());
    }
    if (radio.rdsProgramText()[0] != '\0') {
      Serial.printf("RDS text: %s\n", radio.rdsProgramText());
    }
  }

  const size_t programLength = strlen(radio.rdsProgramText());
  if (programLength > 48U && now - lastScrollTime >= 350U) {
    lastScrollTime = now;
    scrollOffset =
        (scrollOffset + 1U) % static_cast<uint16_t>(programLength + 6U);
    drawRdsProgramText(scrollOffset);
  }
}

void updateRadioStatus() {
  static uint32_t lastStatusTime = 0;
  const uint32_t now = millis();
  if (!radio.available() || now - lastStatusTime < 500U) {
    return;
  }

  lastStatusTime = now;
  radio.refreshReceptionStatus();
  updateRadioFields(false);
}

uint8_t wrapMenuIndex(int16_t value, uint8_t count) {
  while (value < 0) {
    value += count;
  }
  while (value >= count) {
    value -= count;
  }
  return static_cast<uint8_t>(value);
}

uint8_t daysInMonth(uint16_t year, uint8_t month) {
  static constexpr uint8_t DAYS[] = {
      31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31,
  };
  if (month < 1U || month > 12U) {
    return 31U;
  }

  uint8_t result = DAYS[month - 1U];
  const bool leapYear =
      (year % 4U == 0U && year % 100U != 0U) || year % 400U == 0U;
  if (month == 2U && leapYear) {
    result = 29U;
  }
  return result;
}

int16_t wrapValue(int16_t value, int16_t minimum, int16_t maximum) {
  if (value > maximum) {
    return minimum;
  }
  if (value < minimum) {
    return maximum;
  }
  return value;
}

void noteMenuActivity() {
  menuLastActivity = millis();
}

void drawMenuFrame(const char *title) {
  const uint16_t cyan = display.color565(0, 220, 255);
  display.fillScreen(ST77XX_BLACK);
  display.drawRect(0, 0, display.width(), display.height(), ST77XX_WHITE);
  drawCornerMarkers();
  drawCenteredText(title, 7, cyan, 2);
  display.drawFastHLine(8, 27, display.width() - 16, cyan);
  display.drawFastHLine(8, 148, display.width() - 16,
                        display.color565(125, 145, 160));
}

void drawMenuHint(const char *text, uint16_t color = ST77XX_CYAN) {
  display.fillRect(7, 150, display.width() - 14, 17, ST77XX_BLACK);
  drawCenteredText(text, 157, color, 1);
}

const char *irActionName(uint8_t action) {
  switch (static_cast<IrAction>(action)) {
    case IrAction::CHANNEL_UP:
      return "CSATORNA FEL";
    case IrAction::CHANNEL_DOWN:
      return "CSATORNA LE";
    case IrAction::VOLUME_UP:
      return "HANGERO FEL";
    case IrAction::VOLUME_DOWN:
      return "HANGERO LE";
    case IrAction::MUTE:
      return "NEMITAS";
    case IrAction::POWER:
      return "KI / BE";
    case IrAction::SEEK_UP:
      return "KERESES FEL";
    case IrAction::SEEK_DOWN:
      return "KERESES LE";
    case IrAction::DIGIT_0:
      return "SZAM 0";
    case IrAction::DIGIT_1:
      return "SZAM 1";
    case IrAction::DIGIT_2:
      return "SZAM 2";
    case IrAction::DIGIT_3:
      return "SZAM 3";
    case IrAction::DIGIT_4:
      return "SZAM 4";
    case IrAction::DIGIT_5:
      return "SZAM 5";
    case IrAction::DIGIT_6:
      return "SZAM 6";
    case IrAction::DIGIT_7:
      return "SZAM 7";
    case IrAction::DIGIT_8:
      return "SZAM 8";
    case IrAction::DIGIT_9:
      return "SZAM 9";
    case IrAction::CONFIRM:
      return "OK / BETOLT";
    default:
      return "ISMERETLEN";
  }
}

const char *irProtocolName(int16_t protocol) {
  switch (static_cast<decode_type_t>(protocol)) {
    case RC5:
      return "RC5";
    case RC5X:
      return "RC5X";
    case RC6:
      return "RC6";
    case NEC:
      return "NEC";
    case NEC_LIKE:
      return "NEC-LIKE";
    case SONY:
      return "SONY";
    case PANASONIC:
      return "PANASONIC";
    case JVC:
      return "JVC";
    case SAMSUNG:
      return "SAMSUNG";
    case SAMSUNG36:
      return "SAMSUNG36";
    case LG:
      return "LG";
    case LG2:
      return "LG2";
    case SHARP:
      return "SHARP";
    case DENON:
      return "DENON";
    case UNKNOWN:
      return "RAW/HASH";
    default:
      return "EGYEB";
  }
}

void formatIrCode(uint64_t value, char *text, size_t capacity) {
  const uint32_t high = static_cast<uint32_t>(value >> 32U);
  const uint32_t low = static_cast<uint32_t>(value & 0xFFFFFFFFULL);
  if (high != 0U) {
    snprintf(text, capacity, "%08lX%08lX", static_cast<unsigned long>(high),
             static_cast<unsigned long>(low));
  } else {
    snprintf(text, capacity, "%08lX", static_cast<unsigned long>(low));
  }
}

bool irCodesEqual(const IrCodeData &left, const IrCodeData &right) {
  if (!left.valid || !right.valid || left.protocol != right.protocol) {
    return false;
  }

  if (left.protocol != static_cast<int16_t>(UNKNOWN) &&
      (left.address != 0U || left.command != 0U || right.address != 0U ||
       right.command != 0U)) {
    return left.address == right.address && left.command == right.command;
  }
  return left.value == right.value;
}

void drawIrLearningScreen() {
  drawMenuFrame("INFRA TANITAS");

  char positionText[20] = {};
  snprintf(positionText, sizeof(positionText), "FUNKCIO %u / %u",
           irLearningSelection + 1U, IrSettingsStorage::ACTION_COUNT);
  drawCenteredText(positionText, 34, display.color565(125, 145, 160), 1);
  drawCenteredText(irActionName(irLearningSelection), 49, ST77XX_YELLOW, 2);

  if (irLearningDuplicateNotice) {
    drawCenteredText("EZ A GOMB MAR MAS FUNKCIO", 74, ST77XX_RED, 1);
  } else if (irLearningAdvancePending) {
    drawCenteredText("ELMENTVE - KOVETKEZO...", 74, ST77XX_GREEN, 1);
  } else {
    drawCenteredText("NYOMD MEG A KIVANT TAVIRANYITO GOMBOT", 74,
                     ST77XX_CYAN, 1);
  }

  const IrCodeData &code = irCodes[irLearningSelection];
  if (code.valid) {
    char protocolText[32] = {};
    snprintf(protocolText, sizeof(protocolText), "TIPUS: %s   %u BIT",
             irProtocolName(code.protocol), code.bits);
    drawCenteredText(protocolText, 91, ST77XX_WHITE, 1);

    char codeText[20] = {};
    formatIrCode(code.value, codeText, sizeof(codeText));
    drawCenteredText(codeText, 105, ST77XX_WHITE, 2);
  } else {
    drawCenteredText("MEG NINCS BEALLITVA", 96,
                     display.color565(125, 145, 160), 1);
  }

  drawCenteredText("TEKEROVEL BARMELYIK UJRATANITHATO", 132,
                   display.color565(125, 145, 160), 1);
  drawMenuHint("TEKER:VALASZT  KEY:KOVETKEZO  6:KILEP");
}

void enterIrLearning() {
  if (!irSettingsStorageAvailable) {
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2600U;
    drawMenuHint("INFRA TAROLAS NEM ELERHETO", ST77XX_RED);
    return;
  }

  uiScreen = UiScreen::IR_LEARNING;
  irLearningSelection = 0U;
  for (uint8_t action = 0U; action < IrSettingsStorage::ACTION_COUNT;
       ++action) {
    if (!irCodes[action].valid) {
      irLearningSelection = action;
      break;
    }
  }
  irLearningAdvancePending = false;
  irLearningDuplicateNotice = false;
  noteMenuActivity();
  drawIrLearningScreen();
  Serial.println("IR learning opened");
}

void learnIrCode(const IrCodeData &received) {
  for (uint8_t action = 0U; action < IrSettingsStorage::ACTION_COUNT;
       ++action) {
    if (action != irLearningSelection &&
        irCodesEqual(irCodes[action], received)) {
      irLearningDuplicateNotice = true;
      irLearningDuplicateUntil = millis() + 1600U;
      noteMenuActivity();
      drawIrLearningScreen();
      Serial.printf("IR code already assigned to %s\n", irActionName(action));
      return;
    }
  }

  if (!irSettingsStorage.save(irLearningSelection, received)) {
    drawIrLearningScreen();
    drawMenuHint("INFRA MENTESI HIBA", ST77XX_RED);
    noteMenuActivity();
    Serial.println("IR learning save failed");
    return;
  }

  irCodes[irLearningSelection] = received;
  irLearningDuplicateNotice = false;
  irLearningAdvancePending = true;
  irLearningAdvanceAt = millis() + IR_LEARN_CONFIRM_MS;
  noteMenuActivity();
  drawIrLearningScreen();

  char codeText[20] = {};
  formatIrCode(received.value, codeText, sizeof(codeText));
  Serial.printf("IR learned: %s = %s %s\n",
                irActionName(irLearningSelection),
                irProtocolName(received.protocol), codeText);
}

void mainMenuItemText(uint8_t item, char *text, size_t textSize) {
  switch (static_cast<MainMenuItem>(item)) {
    case MainMenuItem::CLOCK_DATE:
      strncpy(text, "ORA / DATUM", textSize);
      break;
    case MainMenuItem::DISPLAY_SETTINGS:
      strncpy(text, "KEPERNYO", textSize);
      break;
    case MainMenuItem::CHANNELS:
      strncpy(text, "CSATORNAK", textSize);
      break;
    case MainMenuItem::INFRARED:
      strncpy(text, "INFRA TANITAS", textSize);
      break;
    case MainMenuItem::MUTE:
      snprintf(text, textSize, "HANG: %s",
               radio.muted() ? "NEMITVA" : "SZOL");
      break;
    case MainMenuItem::EXIT:
      strncpy(text, "VISSZA", textSize);
      break;
    default:
      text[0] = '\0';
      break;
  }
  text[textSize - 1U] = '\0';
}

void drawMainMenuItems() {
  constexpr int16_t firstY = 31;
  constexpr int16_t rowHeight = 19;
  const uint16_t selectedBackground = display.color565(0, 70, 88);

  for (uint8_t item = 0;
       item < static_cast<uint8_t>(MainMenuItem::COUNT); ++item) {
    const bool selected = item == mainMenuSelection;
    const int16_t y = firstY + static_cast<int16_t>(item) * rowHeight;
    const uint16_t background = selected ? selectedBackground : ST77XX_BLACK;
    char text[24] = {};
    mainMenuItemText(item, text, sizeof(text));

    display.fillRect(10, y, display.width() - 20, 17, background);
    display.setTextSize(2);
    display.setTextColor(selected ? ST77XX_YELLOW : ST77XX_WHITE, background);

    int16_t boundsX = 0;
    int16_t boundsY = 0;
    uint16_t boundsWidth = 0;
    uint16_t boundsHeight = 0;
    display.getTextBounds(text, 0, 0, &boundsX, &boundsY, &boundsWidth,
                          &boundsHeight);
    display.setCursor(
        (display.width() - static_cast<int16_t>(boundsWidth)) / 2, y + 1);
    display.print(text);
  }
}

void drawMainMenu() {
  drawMenuFrame("FOMENU");
  drawMainMenuItems();
  drawMenuHint("TEKER:VALASZT  KEY:BELEP  6:KILEP");
}

void enterMainMenu() {
  uiScreen = UiScreen::MAIN_MENU;
  mainMenuSelection = 0;
  menuNoticeActive = false;
  noteMenuActivity();
  drawMainMenu();
  Serial.println("Main menu opened");
}

void drawClockField(uint8_t field, bool valueVisible) {
  static constexpr int16_t FIELD_X[] = {108, 152, 196, 92, 160, 204};
  static constexpr int16_t FIELD_Y[] = {48, 48, 48, 91, 91, 91};
  static constexpr int16_t FIELD_WIDTH[] = {24, 24, 24, 48, 24, 24};
  if (field >= 6U) {
    return;
  }

  const bool selected = clockFieldSelection == field;
  const uint16_t background =
      selected ? display.color565(0, 70, 88) : ST77XX_BLACK;
  const int16_t x = FIELD_X[field];
  const int16_t y = FIELD_Y[field];
  const int16_t width = FIELD_WIDTH[field];
  display.fillRect(x - 2, y - 2, width + 4, 20, background);

  if (!valueVisible) {
    return;
  }

  char text[8] = {};
  switch (field) {
    case 0:
      snprintf(text, sizeof(text), "%02u", clockEdit.hour);
      break;
    case 1:
      snprintf(text, sizeof(text), "%02u", clockEdit.minute);
      break;
    case 2:
      snprintf(text, sizeof(text), "%02u", clockEdit.second);
      break;
    case 3:
      snprintf(text, sizeof(text), "%04u", clockEdit.year);
      break;
    case 4:
      snprintf(text, sizeof(text), "%02u", clockEdit.month);
      break;
    case 5:
      snprintf(text, sizeof(text), "%02u", clockEdit.day);
      break;
    default:
      break;
  }

  display.setTextSize(2);
  display.setTextColor(selected ? (clockFieldEditing ? ST77XX_YELLOW
                                                    : ST77XX_CYAN)
                                : ST77XX_WHITE,
                       background);
  display.setCursor(x, y);
  display.print(text);
}

void drawClockDone() {
  const bool selected = clockFieldSelection == 6U;
  const uint16_t background =
      selected ? display.color565(0, 70, 88) : ST77XX_BLACK;
  display.fillRect(110, 122, 100, 20, background);
  display.setTextSize(2);
  display.setTextColor(selected ? ST77XX_YELLOW : ST77XX_WHITE, background);
  display.setCursor(136, 124);
  display.print("KESZ");
}

void drawClockEditorValues() {
  for (uint8_t field = 0; field < 6U; ++field) {
    const bool visible = !(clockFieldEditing && clockFieldSelection == field) ||
                         clockFieldVisible;
    drawClockField(field, visible);
  }
  drawClockDone();
}

void drawClockEditor() {
  drawMenuFrame("ORA / DATUM BEALLITAS");
  const uint16_t dimText = display.color565(125, 145, 160);

  display.setTextSize(1);
  display.setTextColor(dimText);
  display.setCursor(111, 35);
  display.print("ORA");
  display.setCursor(152, 35);
  display.print("PERC");
  display.setCursor(202, 35);
  display.print("MP");
  display.setCursor(104, 78);
  display.print("EV");
  display.setCursor(163, 78);
  display.print("HO");
  display.setCursor(207, 78);
  display.print("NAP");

  display.setTextSize(2);
  display.setTextColor(ST77XX_WHITE);
  display.setCursor(136, 48);
  display.print(':');
  display.setCursor(180, 48);
  display.print(':');
  display.setCursor(144, 91);
  display.print('-');
  display.setCursor(188, 91);
  display.print('-');

  drawCenteredText("VALTOZAS AZONNAL MENTVE", 113, ST77XX_GREEN, 1);
  drawClockEditorValues();
  drawMenuHint("KEY:SZERK/TOVABB  6:MENT+KILEP");
}

void enterClockEditor() {
  if (!rtcAvailable) {
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2200U;
    drawMenuHint("DS3231 NEM TALALHATO", ST77XX_RED);
    return;
  }

  const DateTime now = rtc.now();
  clockEdit.year = now.year();
  clockEdit.month = now.month();
  clockEdit.day = now.day();
  clockEdit.hour = now.hour();
  clockEdit.minute = now.minute();
  clockEdit.second = now.second();
  clockFieldSelection = 0;
  clockFieldEditing = false;
  clockFieldVisible = true;
  clockEditChanged = false;
  menuLastBlink = millis();
  uiScreen = UiScreen::CLOCK_EDITOR;
  noteMenuActivity();
  drawClockEditor();
  Serial.println("Clock/date editor opened");
}

void applyClockEdit() {
  if (!rtcAvailable || !clockEditChanged) {
    return;
  }

  const uint8_t maximumDay = daysInMonth(clockEdit.year, clockEdit.month);
  clockEdit.day = constrain(clockEdit.day, static_cast<uint8_t>(1), maximumDay);
  rtc.adjust(DateTime(clockEdit.year, clockEdit.month, clockEdit.day,
                      clockEdit.hour, clockEdit.minute, clockEdit.second));
  clockEditChanged = false;
  rtcWasAdjusted = false;
}

void changeClockField(int8_t detent) {
  switch (clockFieldSelection) {
    case 0:
      clockEdit.hour = static_cast<uint8_t>(
          wrapValue(clockEdit.hour + detent, 0, 23));
      break;
    case 1:
      clockEdit.minute = static_cast<uint8_t>(
          wrapValue(clockEdit.minute + detent, 0, 59));
      break;
    case 2:
      clockEdit.second = static_cast<uint8_t>(
          wrapValue(clockEdit.second + detent, 0, 59));
      break;
    case 3:
      clockEdit.year = static_cast<uint16_t>(wrapValue(
          static_cast<int16_t>(clockEdit.year) + detent, EDIT_YEAR_MIN,
          EDIT_YEAR_MAX));
      break;
    case 4:
      clockEdit.month = static_cast<uint8_t>(
          wrapValue(clockEdit.month + detent, 1, 12));
      break;
    case 5: {
      const uint8_t maximumDay = daysInMonth(clockEdit.year, clockEdit.month);
      clockEdit.day = static_cast<uint8_t>(
          wrapValue(clockEdit.day + detent, 1, maximumDay));
      break;
    }
    default:
      return;
  }

  const uint8_t maximumDay = daysInMonth(clockEdit.year, clockEdit.month);
  clockEdit.day = constrain(clockEdit.day, static_cast<uint8_t>(1), maximumDay);
  clockEditChanged = true;
  applyClockEdit();
  clockFieldVisible = true;
  menuLastBlink = millis();
  drawClockEditorValues();
}

void drawDisplayField(uint8_t field, bool valueVisible) {
  if (field >= 2U) {
    return;
  }

  static constexpr int16_t ROW_Y[] = {39, 76};
  const bool selected = displayFieldSelection == field;
  const uint16_t background =
      selected ? display.color565(0, 70, 88) : ST77XX_BLACK;
  const int16_t rowY = ROW_Y[field];
  display.fillRect(20, rowY, display.width() - 40, 30, background);

  display.setTextSize(2);
  display.setTextColor(selected ? ST77XX_CYAN : ST77XX_WHITE, background);
  display.setCursor(field == 0U ? 36 : 70, rowY + 7);
  display.print(field == 0U ? "FENYERO" : "FLIP");

  if (!valueVisible) {
    return;
  }

  char valueText[12] = {};
  if (field == 0U) {
    snprintf(valueText, sizeof(valueText), "%02u / %02u",
             displayEdit.brightness, DisplayConfig::BACKLIGHT_LEVELS);
  } else {
    strncpy(valueText, displayEdit.flipped ? "BE" : "KI",
            sizeof(valueText));
  }
  valueText[sizeof(valueText) - 1U] = '\0';

  int16_t boundsX = 0;
  int16_t boundsY = 0;
  uint16_t boundsWidth = 0;
  uint16_t boundsHeight = 0;
  display.setTextSize(2);
  display.getTextBounds(valueText, 0, 0, &boundsX, &boundsY, &boundsWidth,
                        &boundsHeight);
  display.setTextColor(selected ? (displayFieldEditing ? ST77XX_YELLOW
                                                      : ST77XX_CYAN)
                                : ST77XX_WHITE,
                       background);
  display.setCursor(284 - static_cast<int16_t>(boundsWidth), rowY + 7);
  display.print(valueText);
}

void drawDisplayDone() {
  const bool selected = displayFieldSelection == 2U;
  const uint16_t background =
      selected ? display.color565(0, 70, 88) : ST77XX_BLACK;
  display.fillRect(110, 122, 100, 20, background);
  display.setTextSize(2);
  display.setTextColor(selected ? ST77XX_YELLOW : ST77XX_WHITE, background);
  display.setCursor(136, 124);
  display.print("KESZ");
}

void drawDisplayEditorValues() {
  for (uint8_t field = 0; field < 2U; ++field) {
    const bool visible =
        !(displayFieldEditing && displayFieldSelection == field) ||
        displayFieldVisible;
    drawDisplayField(field, visible);
  }
  drawDisplayDone();
}

void drawDisplayEditor() {
  drawMenuFrame("KEPERNYO BEALLITAS");
  drawDisplayEditorValues();
  drawCenteredText("VALTOZAS AZONNAL LATHATO", 113, ST77XX_GREEN, 1);
  drawMenuHint("KEY:SZERK/TOVABB  6:MENT+KILEP");
}

void enterDisplayEditor() {
  displayEdit = displaySettings;
  displayFieldSelection = 0;
  displayFieldEditing = false;
  displayFieldVisible = true;
  displayEditChanged = false;
  menuLastBlink = millis();
  uiScreen = UiScreen::DISPLAY_EDITOR;
  noteMenuActivity();
  drawDisplayEditor();
  Serial.println("Display editor opened");
}

void saveDisplayEdit() {
  displaySettings = displayEdit;
  bool saved = true;
  if (displayEditChanged) {
    saved = displaySettingsStorageAvailable &&
            displaySettingsStorage.save(displaySettings);
  }
  displayEditChanged = false;

  Serial.printf("Display settings saved: brightness %u/%u, flip %s (%s)\n",
                displaySettings.brightness, DisplayConfig::BACKLIGHT_LEVELS,
                displaySettings.flipped ? "ON" : "OFF",
                saved ? "OK" : "NVS error");
}

void changeDisplayField(int8_t detent) {
  if (displayFieldSelection == 0U) {
    displayEdit.brightness = static_cast<uint8_t>(wrapValue(
        displayEdit.brightness + detent, 1,
        DisplayConfig::BACKLIGHT_LEVELS));
    setBacklightLevel(displayEdit.brightness);
    displayEditChanged = true;
    displayFieldVisible = true;
    menuLastBlink = millis();
    drawDisplayEditorValues();
    return;
  }

  if (displayFieldSelection == 1U) {
    displayEdit.flipped = !displayEdit.flipped;
    displayEditChanged = true;
    displayFieldVisible = true;
    menuLastBlink = millis();
    display.setRotation(displayRotation(displayEdit.flipped));
    drawDisplayEditor();
  }
}

void drawChannelListRows() {
  constexpr uint8_t visibleRows = 4;
  constexpr int16_t firstY = 31;
  constexpr int16_t rowHeight = 29;
  const uint16_t selectedBackground = display.color565(0, 70, 88);
  display.fillRect(7, 29, display.width() - 14, 117, ST77XX_BLACK);

  for (uint8_t row = 0; row < visibleRows; ++row) {
    const uint8_t menuIndex = channelWindowStart + row;
    if (menuIndex >= CHANNEL_MENU_ITEM_COUNT) {
      break;
    }
    const bool selected = menuIndex == channelSelection;
    const int16_t y = firstY + static_cast<int16_t>(row) * rowHeight;
    const uint16_t background = selected ? selectedBackground : ST77XX_BLACK;

    display.fillRect(10, y, display.width() - 20, 25, background);
    display.setTextSize(2);

    if (menuIndex == 0U) {
      constexpr char scanText[] = "AUTOMATA KERESES";
      int16_t boundsX = 0;
      int16_t boundsY = 0;
      uint16_t boundsWidth = 0;
      uint16_t boundsHeight = 0;
      display.getTextBounds(scanText, 0, 0, &boundsX, &boundsY, &boundsWidth,
                            &boundsHeight);
      display.setTextColor(selected ? ST77XX_YELLOW : ST77XX_CYAN,
                           background);
      display.setCursor(
          (display.width() - static_cast<int16_t>(boundsWidth)) / 2, y + 5);
      display.print(scanText);
      continue;
    }

    const uint8_t presetIndex = menuIndex - 1U;
    const bool active = activePreset == presetIndex + 1U;
    const PresetData &preset = presets[presetIndex];
    display.setTextColor(active ? ST77XX_GREEN : background, background);
    display.setCursor(12, y + 5);
    display.print(active ? '>' : ' ');

    display.setTextColor(selected ? ST77XX_YELLOW : ST77XX_WHITE, background);
    display.setCursor(28, y + 5);
    display.printf(presetIndex < PresetStorage::PRESET_COUNT ? "M%u" : "C%u",
                   presetIndex + 1U);

    if (!preset.valid) {
      drawUiText(display, 70, y + 5, "-- URES --",
                 selected ? ST77XX_YELLOW : ST77XX_WHITE, 2);
      continue;
    }

    drawUiText(display, 70, y + 5,
               preset.stationName[0] == '\0' ? "NEVTELEN"
                                               : preset.stationName,
               selected ? ST77XX_YELLOW : ST77XX_WHITE, 2);
    char frequencyText[16] = {};
    snprintf(frequencyText, sizeof(frequencyText), "%u.%u MHz",
             preset.frequency / 100U, (preset.frequency % 100U) / 10U);
    drawRightAlignedText(frequencyText, 302, y + 5,
                         selected ? ST77XX_YELLOW : ST77XX_CYAN, 2);
  }
}

void updateChannelWindow() {
  constexpr uint8_t visibleRows = 4;
  if (channelSelection < channelWindowStart) {
    channelWindowStart = channelSelection;
  } else if (channelSelection >= channelWindowStart + visibleRows) {
    channelWindowStart = channelSelection - visibleRows + 1U;
  }

  const uint8_t maximumStart = CHANNEL_MENU_ITEM_COUNT - visibleRows;
  channelWindowStart = min(channelWindowStart, maximumStart);
}

void drawChannelListHint() {
  if (channelSelection == 0U) {
    drawMenuHint("KEY:INDIT  6:KILEP", ST77XX_YELLOW);
    return;
  }

  char hint[52] = {};
  snprintf(hint, sizeof(hint), "%02u/%02u KEY:BETOLT 4MP:NEV 6:KILEP",
           channelSelection, PresetStorage::CHANNEL_COUNT);
  drawMenuHint(hint);
}

void drawChannelList() {
  drawMenuFrame("CSATORNAK");
  drawChannelListRows();
  drawChannelListHint();
}

void enterChannelList() {
  channelSelection = 0;
  channelWindowStart = 0;

  uiScreen = UiScreen::CHANNEL_LIST;
  menuNoticeActive = false;
  noteMenuActivity();
  drawChannelList();
  Serial.println("Channel list opened");
}

void activateChannelSelection() {
  if (channelSelection == 0U) {
    startAutoScan();
    return;
  }

  const uint8_t slot = channelSelection;
  const uint8_t presetIndex = slot - 1U;
  if (!presets[presetIndex].valid) {
    char message[40] = {};
    snprintf(message, sizeof(message), "%c%u URES - NINCS MIT BETOLTENI",
             slot <= 6U ? 'M' : 'C', slot);
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2200U;
    drawMenuHint(message, ST77XX_YELLOW);
    return;
  }

  recallStoredStation(slot);
}

const char HUNGARIAN_PAGE_LABEL[] = {
    static_cast<char>(HU_UPPER_A_ACUTE),
    static_cast<char>(HU_UPPER_E_ACUTE),
    '\0',
};

KeyboardKey keyboardKeyAt(uint8_t index) {
  KeyboardKey key;
  if (index >= 32U) {
    return key;
  }

  if (keyboardPage == KeyboardPage::LOWERCASE && index < 26U) {
    key.character = static_cast<uint8_t>('a' + index);
    return key;
  }
  if (keyboardPage == KeyboardPage::UPPERCASE && index < 26U) {
    key.character = static_cast<uint8_t>('A' + index);
    return key;
  }

  if (keyboardPage == KeyboardPage::HUNGARIAN) {
    if (index < 9U) {
      key.character = HU_LOWER_A_ACUTE + index;
      return key;
    }
    if (index < 18U) {
      key.character = HU_UPPER_A_ACUTE + index - 9U;
      return key;
    }
    static constexpr char ACCENT_SYMBOLS[] = "-./&+'!?";
    if (index < 26U) {
      key.character = static_cast<uint8_t>(ACCENT_SYMBOLS[index - 18U]);
      return key;
    }
  }

  if (keyboardPage == KeyboardPage::SYMBOLS) {
    if (index < 10U) {
      key.character = static_cast<uint8_t>('0' + index);
      return key;
    }
    static constexpr char SYMBOLS[] = "-.,:;/&+'\"!?()_=";
    if (index < 26U) {
      key.character = static_cast<uint8_t>(SYMBOLS[index - 10U]);
      return key;
    }
  }

  switch (index) {
    case 26:
      key.action = KeyboardAction::BACKSPACE;
      key.label = "<-";
      break;
    case 27:
      key.action = KeyboardAction::SPACE;
      key.label = "SP";
      break;
    case 28:
      key.action = keyboardPage == KeyboardPage::LOWERCASE
                       ? KeyboardAction::UPPERCASE
                       : KeyboardAction::LOWERCASE;
      key.label = keyboardPage == KeyboardPage::LOWERCASE ? "ABC" : "abc";
      break;
    case 29:
      key.action = keyboardPage == KeyboardPage::HUNGARIAN ||
                           keyboardPage == KeyboardPage::SYMBOLS
                       ? KeyboardAction::UPPERCASE
                       : KeyboardAction::HUNGARIAN;
      key.label = keyboardPage == KeyboardPage::HUNGARIAN ||
                          keyboardPage == KeyboardPage::SYMBOLS
                      ? "ABC"
                      : HUNGARIAN_PAGE_LABEL;
      break;
    case 30:
      key.action = keyboardPage == KeyboardPage::SYMBOLS
                       ? KeyboardAction::HUNGARIAN
                       : KeyboardAction::SYMBOLS;
      key.label = keyboardPage == KeyboardPage::SYMBOLS
                      ? HUNGARIAN_PAGE_LABEL
                      : "123";
      break;
    case 31:
      key.action = KeyboardAction::DONE;
      key.label = "OK";
      break;
    default:
      break;
  }
  return key;
}

void drawChannelNameValue() {
  display.fillRect(7, 29, display.width() - 14, 29, ST77XX_BLACK);
  const char *visibleName = channelNameEdit[0] == '\0' ? "---" : channelNameEdit;
  drawCenteredText(visibleName, 32, ST77XX_CYAN, 2);

  const uint8_t length = static_cast<uint8_t>(strlen(channelNameEdit));
  char counter[8] = {};
  snprintf(counter, sizeof(counter), "%u/8", length);
  drawRightAlignedText(counter, 309, 49,
                       length >= 8U ? ST77XX_YELLOW : ST77XX_WHITE, 1);

  if (length < 8U) {
    const int16_t textWidth = uiTextWidth(channelNameEdit, 2);
    const int16_t startX = (display.width() - textWidth) / 2;
    const int16_t cursorX = startX + textWidth;
    display.drawFastHLine(cursorX, 48, 10, ST77XX_YELLOW);
  }
}

void drawKeyboardKey(uint8_t index) {
  constexpr int16_t firstX = 8;
  constexpr int16_t firstY = 60;
  constexpr int16_t cellWidth = 38;
  constexpr int16_t cellHeight = 21;
  constexpr int16_t keyWidth = 36;
  constexpr int16_t keyHeight = 19;
  const int16_t x = firstX + static_cast<int16_t>(index % 8U) * cellWidth;
  const int16_t y = firstY + static_cast<int16_t>(index / 8U) * cellHeight;
  const bool selected = index == keyboardSelection;
  const uint16_t background =
      selected ? display.color565(0, 78, 100) : display.color565(18, 25, 30);
  const uint16_t foreground = selected ? ST77XX_YELLOW : ST77XX_WHITE;
  const KeyboardKey key = keyboardKeyAt(index);

  display.fillRect(x, y, keyWidth, keyHeight, background);
  display.drawRect(x, y, keyWidth, keyHeight,
                   selected ? ST77XX_CYAN : display.color565(70, 85, 95));

  if (key.action == KeyboardAction::CHARACTER) {
    drawUiGlyph(display, x + 12, y + 2, key.character, foreground, 2);
    return;
  }

  const int16_t labelWidth = uiTextWidth(key.label, 1);
  drawUiText(display, x + (keyWidth - labelWidth) / 2, y + 6, key.label,
             foreground, 1);
}

void drawKeyboardKeys() {
  for (uint8_t index = 0; index < 32U; ++index) {
    drawKeyboardKey(index);
  }
}

void drawChannelNameEditorHint() {
  drawMenuHint("TEKER:VALASZT  KEY:IR  6:MENT+KILEP");
}

void drawChannelNameEditor() {
  char title[24] = {};
  snprintf(title, sizeof(title), "CSATORNANEV %c%u",
           channelNameEditSlot <= 6U ? 'M' : 'C', channelNameEditSlot);
  drawMenuFrame(title);
  drawChannelNameValue();
  drawKeyboardKeys();
  drawChannelNameEditorHint();
}

void enterChannelNameEditor() {
  if (channelSelection == 0U ||
      channelSelection > PresetStorage::CHANNEL_COUNT ||
      !presets[channelSelection - 1U].valid) {
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2200U;
    drawMenuHint("URES HELY NEM NEVEZHETO AT", ST77XX_YELLOW);
    return;
  }

  channelNameEditSlot = channelSelection;
  strncpy(channelNameEdit, presets[channelNameEditSlot - 1U].stationName,
          sizeof(channelNameEdit) - 1U);
  channelNameEdit[sizeof(channelNameEdit) - 1U] = '\0';
  keyboardSelection = 0;
  keyboardPage = KeyboardPage::LOWERCASE;
  uiScreen = UiScreen::CHANNEL_NAME_EDITOR;
  menuNoticeActive = false;
  noteMenuActivity();
  drawChannelNameEditor();
  Serial.printf("Channel name editor opened for slot %u\n",
                channelNameEditSlot);
}

bool saveChannelNameEdit(bool exitToRadioAfterSave) {
  while (channelNameEdit[0] != '\0') {
    const size_t length = strlen(channelNameEdit);
    if (length == 0U || channelNameEdit[length - 1U] != ' ') {
      break;
    }
    channelNameEdit[length - 1U] = '\0';
  }

  if (channelNameEdit[0] == '\0') {
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2200U;
    drawMenuHint("A NEV NEM LEHET URES", ST77XX_YELLOW);
    return false;
  }

  PresetData &preset = presets[channelNameEditSlot - 1U];
  if (!presetStorageAvailable ||
      !presetStorage.save(channelNameEditSlot, preset.frequency,
                          channelNameEdit)) {
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2400U;
    drawMenuHint("NEV MENTESI HIBA", ST77XX_RED);
    return false;
  }

  strncpy(preset.stationName, channelNameEdit,
          sizeof(preset.stationName) - 1U);
  preset.stationName[sizeof(preset.stationName) - 1U] = '\0';
  const uint8_t savedSlot = channelNameEditSlot;
  Serial.printf("Channel %u name saved\n", savedSlot);

  if (exitToRadioAfterSave) {
    redrawRadioScreen();
    char message[32] = {};
    snprintf(message, sizeof(message), "%c%u NEV MENTVE",
             savedSlot <= 6U ? 'M' : 'C', savedSlot);
    showTransientMessage(message, ST77XX_GREEN, 2600U);
  } else {
    uiScreen = UiScreen::CHANNEL_LIST;
    channelSelection = savedSlot;
    updateChannelWindow();
    menuNoticeActive = true;
    menuNoticeUntil = millis() + 2200U;
    noteMenuActivity();
    drawChannelList();
    drawMenuHint("NEV MENTVE", ST77XX_GREEN);
  }
  return true;
}

void changeKeyboardPage(KeyboardPage page) {
  keyboardPage = page;
  keyboardSelection = 0;
  drawKeyboardKeys();
  drawChannelNameEditorHint();
}

void activateKeyboardKey() {
  const KeyboardKey key = keyboardKeyAt(keyboardSelection);
  const size_t length = strlen(channelNameEdit);

  switch (key.action) {
    case KeyboardAction::CHARACTER:
      if (length >= sizeof(channelNameEdit) - 1U) {
        menuNoticeActive = true;
        menuNoticeUntil = millis() + 1800U;
        drawMenuHint("LEGFELJEBB 8 KARAKTER", ST77XX_YELLOW);
        return;
      }
      channelNameEdit[length] = static_cast<char>(key.character);
      channelNameEdit[length + 1U] = '\0';
      drawChannelNameValue();
      break;
    case KeyboardAction::BACKSPACE:
      if (length > 0U) {
        channelNameEdit[length - 1U] = '\0';
        drawChannelNameValue();
      }
      break;
    case KeyboardAction::SPACE:
      if (length < sizeof(channelNameEdit) - 1U) {
        channelNameEdit[length] = ' ';
        channelNameEdit[length + 1U] = '\0';
        drawChannelNameValue();
      }
      break;
    case KeyboardAction::LOWERCASE:
      changeKeyboardPage(KeyboardPage::LOWERCASE);
      break;
    case KeyboardAction::UPPERCASE:
      changeKeyboardPage(KeyboardPage::UPPERCASE);
      break;
    case KeyboardAction::HUNGARIAN:
      changeKeyboardPage(KeyboardPage::HUNGARIAN);
      break;
    case KeyboardAction::SYMBOLS:
      changeKeyboardPage(KeyboardPage::SYMBOLS);
      break;
    case KeyboardAction::DONE:
      saveChannelNameEdit(false);
      break;
  }
}

void processChannelNameEditor(int8_t detent,
                              RotaryButtonEvent buttonEvent) {
  if (detent != 0) {
    noteMenuActivity();
    menuNoticeActive = false;
    const uint8_t previousSelection = keyboardSelection;
    keyboardSelection = wrapMenuIndex(
        static_cast<int16_t>(keyboardSelection) + detent, 32U);
    drawKeyboardKey(previousSelection);
    drawKeyboardKey(keyboardSelection);
    drawChannelNameEditorHint();
  }

  if (buttonEvent == RotaryButtonEvent::SHORT_PRESS) {
    noteMenuActivity();
    menuNoticeActive = false;
    activateKeyboardKey();
    if (uiScreen == UiScreen::CHANNEL_NAME_EDITOR && !menuNoticeActive) {
      drawChannelNameEditorHint();
    }
  }
}

void drawAutoScanProgress(const char *statusText, bool force = true) {
  const uint32_t now = millis();
  if (!force && autoScanLastDisplay != 0U &&
      now - autoScanLastDisplay < AUTO_SCAN_DISPLAY_INTERVAL_MS) {
    return;
  }
  autoScanLastDisplay = now;
  autoScanCanvas.fillScreen(ST77XX_BLACK);

  char frequencyText[20] = {};
  snprintf(frequencyText, sizeof(frequencyText), "%u.%u MHz",
           autoScanFrequency / 100U, (autoScanFrequency % 100U) / 10U);
  drawCenteredCanvasText(autoScanCanvas, frequencyText, 7, ST77XX_WHITE, 2);

  constexpr int16_t barX = 13;
  constexpr int16_t barY = 33;
  constexpr int16_t barWidth = 280;
  constexpr int16_t innerWidth = barWidth - 4;
  const uint32_t progress =
      autoScanFrequency <= RadioController::MIN_FREQUENCY
          ? 0U
          : static_cast<uint32_t>(autoScanFrequency -
                                  RadioController::MIN_FREQUENCY);
  const uint32_t range =
      RadioController::MAX_FREQUENCY - RadioController::MIN_FREQUENCY;
  const int16_t filled = static_cast<int16_t>(progress * innerWidth / range);
  autoScanCanvas.drawRect(barX, barY, barWidth, 12, ST77XX_WHITE);
  if (filled > 0) {
    autoScanCanvas.fillRect(barX + 2, barY + 2, filled, 8, ST77XX_GREEN);
  }

  char foundText[24] = {};
  snprintf(foundText, sizeof(foundText), "TALALT: %02u / %02u",
           autoScanCount, PresetStorage::CHANNEL_COUNT);
  drawCenteredCanvasText(autoScanCanvas, foundText, 53, ST77XX_CYAN, 2);

  if (autoScanCount == 0U) {
    drawCenteredCanvasText(autoScanCanvas, "MEG NINCS TALALAT", 77,
                           display.color565(125, 145, 160), 2);
  } else {
    const PresetData &last = autoScanResults[autoScanCount - 1U];
    char lastText[32] = {};
    snprintf(lastText, sizeof(lastText), "%s  %u.%u MHz",
             last.stationName, last.frequency / 100U,
             (last.frequency % 100U) / 10U);
    drawCenteredCanvasText(
        autoScanCanvas, lastText, 77,
        strcmp(last.stationName, "N/A") == 0 ? ST77XX_YELLOW : ST77XX_GREEN,
        2);
  }

  drawCenteredCanvasText(autoScanCanvas, statusText, 102, ST77XX_YELLOW, 1);
  display.drawRGBBitmap(AUTO_SCAN_CANVAS_X, AUTO_SCAN_CANVAS_Y,
                        autoScanCanvas.getBuffer(), AUTO_SCAN_CANVAS_WIDTH,
                        AUTO_SCAN_CANVAS_HEIGHT);
}

void drawAutoScanScreen() {
  drawMenuFrame("AUTOMATA KERESES");
  drawAutoScanProgress("FM SAV VIZSGALATA...");
  drawMenuHint("KERES FOLYAMATBAN  6:MEGSZAKIT");
}

void tuneAutoScanFrequency(uint16_t frequency) {
  if (frequency > RadioController::MAX_FREQUENCY) {
    return;
  }
  autoScanFrequency = frequency;
  radio.setFrequency(autoScanFrequency);
  autoScanPhase = AutoScanPhase::SETTLING;
  autoScanPhaseStarted = millis();
  drawAutoScanProgress("FM SAV VIZSGALATA...", false);
}

bool storeAutoScanResults() {
  bool success = presetStorageAvailable;
  for (uint8_t index = 0; index < PresetStorage::CHANNEL_COUNT; ++index) {
    if (index < autoScanCount) {
      presets[index] = autoScanResults[index];
      if (!presetStorage.save(index + 1U, presets[index].frequency,
                              presets[index].stationName)) {
        success = false;
      }
    } else {
      presets[index] = {};
      if (!presetStorage.clear(index + 1U)) {
        success = false;
      }
    }
  }
  return success;
}

void drawAutoScanComplete() {
  display.fillRect(7, 31, display.width() - 14, 113, ST77XX_BLACK);
  drawCenteredText("KERES KESZ", 42, ST77XX_GREEN, 2);

  char resultText[32] = {};
  snprintf(resultText, sizeof(resultText), "TALALT ALLOMAS: %u",
           autoScanCount);
  drawCenteredText(resultText, 72,
                   autoScanCount > 0U ? ST77XX_CYAN : ST77XX_YELLOW, 2);
  drawCenteredText(autoScanCount > 0U ? "30 HELY MENTVE, M1-M6: GOMBOK"
                                      : "A REGI ALLOMAS VISSZAALLITVA",
                   104, ST77XX_WHITE, 1);
  drawCenteredText(autoScanSaveSucceeded ? "LISTA MENTVE"
                                         : "NVS MENTESI HIBA",
                   130,
                   autoScanSaveSucceeded ? ST77XX_GREEN : ST77XX_RED, 1);
  drawMenuHint("VISSZA A RADIOHOZ...");
}

void finishAutoScan() {
  drawAutoScanProgress("LISTA MENTESE...");
  // If reception is unavailable and nothing was found, keep the user's old
  // list instead of replacing every stored channel with an empty entry.
  autoScanSaveSucceeded =
      autoScanCount == 0U ? true : storeAutoScanResults();

  if (autoScanCount > 0U) {
    activePreset = 1U;
    radio.setFrequency(autoScanResults[0].frequency);
    if (presetStorageAvailable) {
      presetStorage.saveLastChannel(activePreset);
    }
  } else {
    activePreset = autoScanOriginalPreset;
    radio.setFrequency(autoScanOriginalFrequency);
  }
  radio.setMuted(autoScanOriginalMuted);

  autoScanPhase = AutoScanPhase::COMPLETE;
  autoScanPhaseStarted = millis();
  drawAutoScanComplete();
  Serial.printf("Automatic scan complete: %u stations, storage %s\n",
                autoScanCount, autoScanSaveSucceeded ? "OK" : "error");
}

void advanceAutoScan(bool stationWasFound) {
  if (autoScanCount >= PresetStorage::CHANNEL_COUNT) {
    finishAutoScan();
    return;
  }

  const uint16_t increment =
      stationWasFound ? RadioController::FREQUENCY_STEP * 2U
                      : RadioController::FREQUENCY_STEP;
  const uint16_t nextFrequency = autoScanFrequency + increment;
  if (nextFrequency > RadioController::MAX_FREQUENCY) {
    finishAutoScan();
    return;
  }
  tuneAutoScanFrequency(nextFrequency);
}

void startAutoScan() {
  if (!radio.available() || !presetStorageAvailable) {
    showTransientMessage("AUTOMATA KERESES NEM INDITHATO", ST77XX_RED,
                         3000U);
    return;
  }

  autoScanOriginalFrequency = radio.frequency();
  autoScanOriginalPreset = activePreset;
  autoScanOriginalMuted = radio.muted();
  memset(autoScanResults, 0, sizeof(autoScanResults));
  autoScanCount = 0;
  autoScanSaveSucceeded = true;
  autoScanLastRdsPoll = 0;
  autoScanRdsStableSince = 0;
  autoScanLastDisplay = 0;
  autoScanRdsCandidate[0] = '\0';
  activePreset = 0;
  radio.setMuted(true);
  uiScreen = UiScreen::AUTO_SCAN;
  drawAutoScanScreen();
  tuneAutoScanFrequency(RadioController::MIN_FREQUENCY);
  Serial.println("Automatic FM scan started");
}

void cancelAutoScan() {
  if (autoScanPhase == AutoScanPhase::COMPLETE) {
    autoScanPhase = AutoScanPhase::IDLE;
    redrawRadioScreen();
    return;
  }

  radio.setFrequency(autoScanOriginalFrequency);
  activePreset = autoScanOriginalPreset;
  radio.setMuted(autoScanOriginalMuted);
  autoScanPhase = AutoScanPhase::IDLE;
  redrawRadioScreen();
  showTransientMessage("AUTOMATA KERESES MEGSZAKITVA", ST77XX_YELLOW,
                       2600U);
  Serial.println("Automatic FM scan cancelled");
}

void updateAutoScan() {
  const uint32_t now = millis();
  if (autoScanPhase == AutoScanPhase::SETTLING) {
    if (now - autoScanPhaseStarted < AUTO_SCAN_SETTLE_MS) {
      return;
    }

    radio.refreshReceptionStatus();
    if (radio.stationValid() && radio.rssi() >= AUTO_SCAN_MIN_RSSI) {
      PresetData &result = autoScanResults[autoScanCount];
      result = {};
      result.valid = true;
      result.frequency = autoScanFrequency;
      strncpy(result.stationName, "N/A", sizeof(result.stationName));
      ++autoScanCount;
      autoScanPhase = AutoScanPhase::RDS_WAIT;
      autoScanPhaseStarted = now;
      autoScanLastRdsPoll = 0;
      autoScanRdsStableSince = 0;
      autoScanRdsCandidate[0] = '\0';
      drawAutoScanProgress("RDS NEV KERESE...");
      Serial.printf("Scan found %u.%u MHz, RSSI %u\n",
                    autoScanFrequency / 100U,
                    (autoScanFrequency % 100U) / 10U, radio.rssi());
    } else {
      advanceAutoScan(false);
    }
    return;
  }

  if (autoScanPhase == AutoScanPhase::RDS_WAIT) {
    if (now - autoScanLastRdsPoll >= AUTO_SCAN_RDS_POLL_MS) {
      autoScanLastRdsPoll = now;
      radio.pollRds();
      if (radio.rdsStationName()[0] != '\0') {
        PresetData &result = autoScanResults[autoScanCount - 1U];
        if (strncmp(autoScanRdsCandidate, radio.rdsStationName(),
                    sizeof(autoScanRdsCandidate)) != 0) {
          strncpy(autoScanRdsCandidate, radio.rdsStationName(),
                  sizeof(autoScanRdsCandidate) - 1U);
          autoScanRdsCandidate[sizeof(autoScanRdsCandidate) - 1U] = '\0';
          strncpy(result.stationName, autoScanRdsCandidate,
                  sizeof(result.stationName) - 1U);
          result.stationName[sizeof(result.stationName) - 1U] = '\0';
          autoScanRdsStableSince = now;
          drawAutoScanProgress("RDS NEV ELLENORZESE...");
        } else if (autoScanRdsStableSince != 0U &&
                   now - autoScanRdsStableSince >=
                       AUTO_SCAN_RDS_STABLE_MS) {
          drawAutoScanProgress("RDS NEV BEOLVASVA");
          advanceAutoScan(true);
          return;
        }
      }
    }

    if (now - autoScanPhaseStarted >= AUTO_SCAN_RDS_WAIT_MS) {
      drawAutoScanProgress(autoScanRdsCandidate[0] == '\0'
                               ? "RDS NINCS - NEV: N/A"
                               : "RDS NEV MENTVE");
      advanceAutoScan(true);
    }
    return;
  }

  if (autoScanPhase == AutoScanPhase::COMPLETE &&
      now - autoScanPhaseStarted >= AUTO_SCAN_RESULT_MS) {
    const uint8_t found = autoScanCount;
    autoScanPhase = AutoScanPhase::IDLE;
    redrawRadioScreen();
    char message[40] = {};
    snprintf(message, sizeof(message), "KERES KESZ: %u ALLOMAS", found);
    showTransientMessage(message,
                         autoScanSaveSucceeded ? ST77XX_GREEN : ST77XX_RED,
                         3200U);
  }
}

void redrawRadioScreen() {
  uiScreen = UiScreen::RADIO;
  controlMode = ControlMode::VOLUME;
  clearIrChannelEntry(false);
  transientMessageActive = false;
  menuNoticeActive = false;
  drawStaticRadioScreen();
  updateRadioFields(true);
  drawRdsStationName();
  drawRdsProgramText(0);
  updateRtcDisplay(true);
  Serial.println("Returned to radio screen");
}

void exitMenuToRadio() {
  if (uiScreen == UiScreen::AUTO_SCAN) {
    cancelAutoScan();
    return;
  }
  if (uiScreen == UiScreen::CLOCK_EDITOR) {
    applyClockEdit();
  } else if (uiScreen == UiScreen::DISPLAY_EDITOR) {
    saveDisplayEdit();
  }
  redrawRadioScreen();
}

void activateMainMenuItem() {
  switch (static_cast<MainMenuItem>(mainMenuSelection)) {
    case MainMenuItem::CLOCK_DATE:
      enterClockEditor();
      break;
    case MainMenuItem::DISPLAY_SETTINGS:
      enterDisplayEditor();
      break;
    case MainMenuItem::CHANNELS:
      enterChannelList();
      break;
    case MainMenuItem::INFRARED:
      enterIrLearning();
      break;
    case MainMenuItem::MUTE:
      if (radio.available()) {
        radio.toggleMute();
        drawMainMenuItems();
        Serial.println(radio.muted() ? "Radio muted from menu"
                                     : "Radio unmuted from menu");
      }
      break;
    case MainMenuItem::EXIT:
      exitMenuToRadio();
      break;
    default:
      break;
  }
}

void processMenuRotary(int8_t detent, RotaryButtonEvent buttonEvent) {
  if (uiScreen == UiScreen::CHANNEL_NAME_EDITOR) {
    processChannelNameEditor(detent, buttonEvent);
    return;
  }

  if (uiScreen == UiScreen::AUTO_SCAN) {
    if (buttonEvent == RotaryButtonEvent::SHORT_PRESS) {
      cancelAutoScan();
    }
    return;
  }

  if (uiScreen == UiScreen::IR_LEARNING) {
    if (detent != 0) {
      irLearningSelection = wrapMenuIndex(
          static_cast<int16_t>(irLearningSelection) + detent,
          IrSettingsStorage::ACTION_COUNT);
      irLearningAdvancePending = false;
      irLearningDuplicateNotice = false;
      noteMenuActivity();
      drawIrLearningScreen();
    } else if (buttonEvent == RotaryButtonEvent::SHORT_PRESS) {
      irLearningSelection = wrapMenuIndex(irLearningSelection + 1,
                                          IrSettingsStorage::ACTION_COUNT);
      irLearningAdvancePending = false;
      irLearningDuplicateNotice = false;
      noteMenuActivity();
      drawIrLearningScreen();
    }
    return;
  }

  if (detent != 0) {
    noteMenuActivity();
    menuNoticeActive = false;
    if (uiScreen == UiScreen::MAIN_MENU) {
      mainMenuSelection = wrapMenuIndex(
          static_cast<int16_t>(mainMenuSelection) + detent,
          static_cast<uint8_t>(MainMenuItem::COUNT));
      drawMainMenuItems();
      drawMenuHint("TEKER:VALASZT  KEY:BELEP  6:KILEP");
    } else if (uiScreen == UiScreen::CLOCK_EDITOR) {
      if (clockFieldEditing && clockFieldSelection < 6U) {
        changeClockField(detent);
      } else {
        clockFieldSelection = wrapMenuIndex(
            static_cast<int16_t>(clockFieldSelection) + detent, 7U);
        clockFieldVisible = true;
        drawClockEditorValues();
      }
    } else if (uiScreen == UiScreen::DISPLAY_EDITOR) {
      if (displayFieldEditing && displayFieldSelection < 2U) {
        changeDisplayField(detent);
      } else {
        displayFieldSelection = wrapMenuIndex(
            static_cast<int16_t>(displayFieldSelection) + detent, 3U);
        displayFieldVisible = true;
        drawDisplayEditorValues();
      }
    } else if (uiScreen == UiScreen::CHANNEL_LIST) {
      channelSelection = wrapMenuIndex(
          static_cast<int16_t>(channelSelection) + detent,
          CHANNEL_MENU_ITEM_COUNT);
      updateChannelWindow();
      drawChannelListRows();
      drawChannelListHint();
    }
  }

  if (buttonEvent == RotaryButtonEvent::NONE) {
    return;
  }
  noteMenuActivity();
  menuNoticeActive = false;

  if (uiScreen == UiScreen::CHANNEL_LIST &&
      buttonEvent == RotaryButtonEvent::VERY_LONG_PRESS) {
    enterChannelNameEditor();
    return;
  }

  if (buttonEvent != RotaryButtonEvent::SHORT_PRESS) {
    return;
  }

  if (uiScreen == UiScreen::MAIN_MENU) {
    activateMainMenuItem();
    return;
  }

  if (uiScreen == UiScreen::CLOCK_EDITOR) {
    if (clockFieldSelection == 6U) {
      enterMainMenu();
      return;
    }

    if (!clockFieldEditing) {
      clockFieldEditing = true;
    } else if (clockFieldSelection < 5U) {
      clockFieldEditing = false;
      drawClockField(clockFieldSelection, true);
      ++clockFieldSelection;
      clockFieldEditing = true;
    } else {
      applyClockEdit();
      clockFieldEditing = false;
      drawClockField(clockFieldSelection, true);
      clockFieldSelection = 6U;
    }

    clockFieldVisible = true;
    menuLastBlink = millis();
    drawClockEditorValues();
    return;
  }

  if (uiScreen == UiScreen::CHANNEL_LIST) {
    activateChannelSelection();
    return;
  }

  if (displayFieldSelection == 2U) {
    saveDisplayEdit();
    enterMainMenu();
    return;
  }

  if (!displayFieldEditing) {
    displayFieldEditing = true;
  } else if (displayFieldSelection == 0U) {
    displayFieldEditing = false;
    drawDisplayField(displayFieldSelection, true);
    displayFieldSelection = 1U;
    displayFieldEditing = true;
  } else {
    displayFieldEditing = false;
    drawDisplayField(displayFieldSelection, true);
    displayFieldSelection = 2U;
  }

  displayFieldVisible = true;
  menuLastBlink = millis();
  drawDisplayEditorValues();
}

void updateIrLearningScreen() {
  const uint32_t now = millis();
  if (irLearningDuplicateNotice &&
      static_cast<int32_t>(now - irLearningDuplicateUntil) >= 0) {
    irLearningDuplicateNotice = false;
    drawIrLearningScreen();
  }

  if (!irLearningAdvancePending ||
      static_cast<int32_t>(now - irLearningAdvanceAt) < 0) {
    return;
  }

  irLearningAdvancePending = false;
  if (irLearningSelection + 1U >= IrSettingsStorage::ACTION_COUNT) {
    enterMainMenu();
    return;
  }

  ++irLearningSelection;
  drawIrLearningScreen();
}

void updateMenuScreen() {
  if (uiScreen == UiScreen::RADIO) {
    return;
  }

  if (uiScreen == UiScreen::AUTO_SCAN) {
    updateAutoScan();
    return;
  }

  if (uiScreen == UiScreen::IR_LEARNING) {
    updateIrLearningScreen();
  }

  const uint32_t now = millis();
  const uint32_t timeout =
      uiScreen == UiScreen::IR_LEARNING ? IR_MENU_TIMEOUT_MS : MENU_TIMEOUT_MS;
  if (now - menuLastActivity >= timeout) {
    Serial.println("Menu timeout");
    exitMenuToRadio();
    return;
  }

  if (menuNoticeActive &&
      static_cast<int32_t>(now - menuNoticeUntil) >= 0) {
    menuNoticeActive = false;
    if (uiScreen == UiScreen::CHANNEL_LIST) {
      drawChannelListHint();
    } else if (uiScreen == UiScreen::CHANNEL_NAME_EDITOR) {
      drawChannelNameEditorHint();
    } else {
      drawMenuHint("TEKER:VALASZT  KEY:BELEP  6:KILEP");
    }
  }

  if (uiScreen == UiScreen::CLOCK_EDITOR && clockFieldEditing &&
      clockFieldSelection < 6U && now - menuLastBlink >= MENU_BLINK_MS) {
    menuLastBlink = now;
    clockFieldVisible = !clockFieldVisible;
    drawClockField(clockFieldSelection, clockFieldVisible);
  } else if (uiScreen == UiScreen::DISPLAY_EDITOR && displayFieldEditing &&
             displayFieldSelection < 2U &&
             now - menuLastBlink >= MENU_BLINK_MS) {
    menuLastBlink = now;
    displayFieldVisible = !displayFieldVisible;
    drawDisplayField(displayFieldSelection, displayFieldVisible);
  }
}

void processRotary() {
  const int8_t detent = rotary.readDetent();
  const RotaryButtonEvent buttonEvent = rotary.updateButton();

  if (uiScreen != UiScreen::RADIO) {
    processMenuRotary(detent, buttonEvent);
    return;
  }

  if (irSeekPhase != IrSeekPhase::IDLE &&
      (detent != 0 || buttonEvent != RotaryButtonEvent::NONE)) {
    cancelIrSeek(false);
  }

  if (irChannelEntryDigits != 0U &&
      (detent != 0 || buttonEvent != RotaryButtonEvent::NONE)) {
    clearIrChannelEntry(true);
  }

  if (detent != 0 && radio.available()) {
    if (controlMode == ControlMode::VOLUME) {
      radio.changeVolume(detent);
      Serial.printf("Volume: %u / %u\n", radio.volume(),
                    RadioController::MAX_VOLUME);
    } else {
      activePreset = 0;
      radio.tuneSteps(detent);
      Serial.printf("Frequency: %u.%u MHz\n", radio.frequency() / 100U,
                    (radio.frequency() % 100U) / 10U);
    }
    updateRadioFields(false);
  }

  if (buttonEvent == RotaryButtonEvent::NONE) {
    return;
  }

  if (buttonEvent == RotaryButtonEvent::VERY_LONG_PRESS) {
    return;
  }

  if (buttonEvent == RotaryButtonEvent::LONG_PRESS) {
    if (!radio.available()) {
      return;
    }
    controlMode = controlMode == ControlMode::VOLUME ? ControlMode::TUNING
                                                     : ControlMode::VOLUME;
    Serial.println(controlMode == ControlMode::TUNING
                       ? "Rotary mode: FM tuning"
                       : "Rotary mode: volume");
  } else if (controlMode == ControlMode::TUNING) {
    controlMode = ControlMode::VOLUME;
    Serial.println("Rotary mode: volume");
  } else {
    enterMainMenu();
    return;
  }

  updateRadioFields(false);
}

void loadStoredPresets() {
  presetStorageAvailable = presetStorage.begin();
  Serial.printf("Preset storage: %s\n",
                presetStorageAvailable ? "OK" : "not available");

  for (uint8_t slot = 1; slot <= PresetStorage::CHANNEL_COUNT; ++slot) {
    if (presetStorageAvailable &&
        presetStorage.load(slot, presets[slot - 1U])) {
      Serial.printf("  M%u: %u.%u MHz, name: %s\n", slot,
                    presets[slot - 1U].frequency / 100U,
                    (presets[slot - 1U].frequency % 100U) / 10U,
                    presets[slot - 1U].stationName);
    } else {
      presets[slot - 1U] = {};
      Serial.printf("  M%u: empty\n", slot);
    }
  }

  activePreset = 0U;
  if (presetStorageAvailable) {
    const uint8_t storedLastChannel = presetStorage.loadLastChannel();
    if (storedLastChannel >= 1U &&
        storedLastChannel <= PresetStorage::CHANNEL_COUNT &&
        presets[storedLastChannel - 1U].valid) {
      activePreset = storedLastChannel;
    } else {
      for (uint8_t slot = 1U; slot <= PresetStorage::CHANNEL_COUNT; ++slot) {
        if (presets[slot - 1U].valid) {
          activePreset = slot;
          presetStorage.saveLastChannel(activePreset);
          break;
        }
      }
    }
  }

  if (activePreset != 0U) {
    Serial.printf("Startup channel: %c%u, %u.%u MHz\n",
                  activePreset <= 6U ? 'M' : 'C', activePreset,
                  presets[activePreset - 1U].frequency / 100U,
                  (presets[activePreset - 1U].frequency % 100U) / 10U);
  } else {
    Serial.println("Startup channel: no stored station, using 100.0 MHz");
  }
}

void saveCurrentStation(uint8_t slot) {
  if (slot < 1U || slot > PresetStorage::PRESET_COUNT ||
      !presetStorageAvailable || !radio.available()) {
    showTransientMessage("MEMORIA MENTESI HIBA", ST77XX_RED);
    return;
  }

  // Holding one of the six physical memory buttons while a channel from the
  // 30-entry list is active moves it to that button.  The old button content
  // moves back to the original list position, so no station is lost and no
  // duplicate entry remains.
  if (activePreset >= 1U && activePreset <= PresetStorage::CHANNEL_COUNT &&
      activePreset != slot && presets[activePreset - 1U].valid) {
    const uint8_t sourceSlot = activePreset;
    const PresetData sourcePreset = presets[sourceSlot - 1U];
    const PresetData displacedPreset = presets[slot - 1U];

    bool saved = presetStorage.save(slot, sourcePreset.frequency,
                                    sourcePreset.stationName);
    if (saved) {
      saved = displacedPreset.valid
                  ? presetStorage.save(sourceSlot, displacedPreset.frequency,
                                       displacedPreset.stationName)
                  : presetStorage.clear(sourceSlot);
    }
    if (!saved) {
      showTransientMessage("MEMORIA CSERE HIBA", ST77XX_RED);
      return;
    }

    presets[slot - 1U] = sourcePreset;
    presets[sourceSlot - 1U] = displacedPreset;
    activePreset = slot;
    presetStorage.saveLastChannel(activePreset);
    drawRdsStationName();

    char message[48] = {};
    snprintf(message, sizeof(message), displacedPreset.valid
                 ? "%c%u <-> M%u CSERE"
                 : "%c%u -> M%u ATHELYEZVE",
             sourceSlot <= PresetStorage::PRESET_COUNT ? 'M' : 'C',
             sourceSlot, slot);
    showTransientMessage(message, ST77XX_GREEN, 3000U);
    Serial.println(message);
    return;
  }

  char stationName[9] = {};
  if (radio.rdsStationName()[0] != '\0') {
    strncpy(stationName, radio.rdsStationName(), sizeof(stationName) - 1U);
  } else {
    snprintf(stationName, sizeof(stationName), "%u.%u",
             radio.frequency() / 100U, (radio.frequency() % 100U) / 10U);
  }

  if (!presetStorage.save(slot, radio.frequency(), stationName)) {
    showTransientMessage("MEMORIA MENTESI HIBA", ST77XX_RED);
    return;
  }

  PresetData &preset = presets[slot - 1U];
  preset.valid = true;
  preset.frequency = radio.frequency();
  strncpy(preset.stationName, stationName, sizeof(preset.stationName) - 1U);
  preset.stationName[sizeof(preset.stationName) - 1U] = '\0';
  activePreset = slot;
  presetStorage.saveLastChannel(activePreset);
  drawRdsStationName();

  char message[48];
  snprintf(message, sizeof(message), "M%u MENTVE: %s  %u.%u MHz", slot,
           preset.stationName, preset.frequency / 100U,
           (preset.frequency % 100U) / 10U);
  showTransientMessage(message, ST77XX_GREEN, 3000U);
  Serial.println(message);
}

void recallStoredStation(uint8_t slot) {
  if (slot < 1U || slot > PresetStorage::CHANNEL_COUNT ||
      !radio.available()) {
    return;
  }

  const PresetData &preset = presets[slot - 1U];
  if (!preset.valid) {
    char emptyMessage[40];
    snprintf(emptyMessage, sizeof(emptyMessage),
             "%c%u URES - NINCS MIT BETOLTENI",
             slot <= 6U ? 'M' : 'C', slot);
    showTransientMessage(emptyMessage, ST77XX_YELLOW, 3000U);
    return;
  }

  const bool selectedFromChannelMenu = uiScreen == UiScreen::CHANNEL_LIST;
  activePreset = slot;
  controlMode = ControlMode::VOLUME;
  radio.setFrequency(preset.frequency);
  if (presetStorageAvailable) {
    presetStorage.saveLastChannel(activePreset);
  }
  if (selectedFromChannelMenu) {
    redrawRadioScreen();
  } else {
    updateRadioFields(false);
    drawRdsStationName();
    drawRdsProgramText(0);
  }

  char message[48];
  snprintf(message, sizeof(message), "%c%u BETOLTVE: %s  %u.%u MHz",
           slot <= 6U ? 'M' : 'C', slot, preset.stationName,
           preset.frequency / 100U,
           (preset.frequency % 100U) / 10U);
  showTransientMessage(message, ST77XX_CYAN, 2600U);
  Serial.println(message);
}

void stepStoredChannel(int8_t direction) {
  if (direction == 0 || !radio.available()) {
    return;
  }

  int16_t candidate = activePreset;
  for (uint8_t checked = 0U; checked < PresetStorage::CHANNEL_COUNT;
       ++checked) {
    candidate += direction > 0 ? 1 : -1;
    if (candidate > PresetStorage::CHANNEL_COUNT) {
      candidate = 1;
    } else if (candidate < 1) {
      candidate = PresetStorage::CHANNEL_COUNT;
    }

    if (presets[candidate - 1U].valid) {
      recallStoredStation(static_cast<uint8_t>(candidate));
      return;
    }
  }

  showTransientMessage("NINCS MENTETT CSATORNA", ST77XX_YELLOW, 2200U);
}

void waitForIrIdle(uint32_t stableHighMs, uint32_t maximumWaitMs) {
  const uint32_t started = millis();
  uint32_t highSince = 0U;
  while (millis() - started < maximumWaitMs) {
    if (digitalRead(Pins::IR_INPUT) == HIGH) {
      if (highSince == 0U) {
        highSince = millis();
      }
      if (millis() - highSince >= stableHighMs) {
        return;
      }
    } else {
      highSince = 0U;
    }
    delay(2);
  }
}

void enterInfraredStandby() {
  const bool restoreMuted = radio.available() ? radio.muted() : true;
  if (radio.available()) {
    radio.setMuted(true);
  }

  display.fillScreen(ST77XX_BLACK);
  setBacklightLevel(0U);
  display.enableDisplay(false);
  display.enableSleep(true);

  irReceiver.disableIRIn();
  pinMode(Pins::IR_INPUT, INPUT);
  // Wait until the power key is released. Otherwise a held key's next repeat
  // frame would wake the ESP32 immediately after it enters light sleep.
  waitForIrIdle(160U, 1800U);

  const esp_err_t wakeResult = esp_sleep_enable_ext0_wakeup(
      static_cast<gpio_num_t>(Pins::IR_INPUT), 0);
  Serial.printf("Entering IR light sleep: %s\n",
                wakeResult == ESP_OK ? "OK" : "wake setup error");
  Serial.flush();

  if (wakeResult == ESP_OK) {
    esp_light_sleep_start();
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_EXT0);
  }

  // The wake-up edge is the beginning of an IR frame. Wait for that whole
  // frame and the released key before restarting the decoder, so it cannot
  // be interpreted as another POWER command.
  waitForIrIdle(180U, 1800U);
  display.enableSleep(false);
  delay(125);
  display.enableDisplay(true);
  setBacklightLevel(displaySettings.brightness);
  irReceiver.enableIRIn(false);
  irSuppressUntil = millis() + IR_WAKE_SUPPRESS_MS;

  if (radio.available()) {
    radio.setMuted(restoreMuted);
  }
  redrawRadioScreen();
  Serial.println("Woke from IR light sleep");
}

uint16_t nextIrSeekFrequency(uint16_t frequency, int8_t direction) {
  if (direction > 0) {
    return frequency >= RadioController::MAX_FREQUENCY
               ? RadioController::MIN_FREQUENCY
               : frequency + RadioController::FREQUENCY_STEP;
  }
  return frequency <= RadioController::MIN_FREQUENCY
             ? RadioController::MAX_FREQUENCY
             : frequency - RadioController::FREQUENCY_STEP;
}

void finishIrSeek(bool found) {
  const int8_t finishedDirection = irSeekDirection;
  irSeekPhase = IrSeekPhase::IDLE;

  if (found) {
    activePreset = 0U;
  } else {
    radio.setFrequency(irSeekOriginalFrequency);
    activePreset = irSeekOriginalPreset;
  }
  radio.setMuted(irSeekOriginalMuted);
  updateRadioFields(false);
  drawRdsStationName();
  drawRdsProgramText(0U);

  if (found) {
    char message[40] = {};
    snprintf(message, sizeof(message), "TALALAT: %u.%u MHz  %s",
             radio.frequency() / 100U, (radio.frequency() % 100U) / 10U,
             finishedDirection > 0 ? "FEL" : "LE");
    showTransientMessage(message, ST77XX_GREEN, 2600U);
    Serial.println(message);
  } else {
    showTransientMessage("NINCS UJ VETEL - EREDETI MARADT", ST77XX_RED,
                         2800U);
    Serial.println("IR station seek found no new reception");
  }

  irReceiver.resume();
  irSuppressUntil = millis() + 450U;
}

void startIrSeek(int8_t direction) {
  if (!radio.available() || direction == 0 ||
      irSeekPhase != IrSeekPhase::IDLE) {
    return;
  }

  irSeekDirection = direction > 0 ? 1 : -1;
  irSeekOriginalFrequency = radio.frequency();
  irSeekOriginalPreset = activePreset;
  irSeekOriginalMuted = radio.muted();
  irSeekStepsChecked = 1U;
  irSeekPhase = IrSeekPhase::SETTLING;

  radio.setMuted(true);
  activePreset = 0U;
  radio.setFrequency(
      nextIrSeekFrequency(irSeekOriginalFrequency, irSeekDirection));
  updateRadioFields(false);
  drawRdsStationName();
  drawRdsProgramText(0U);
  showTransientMessage(irSeekDirection > 0 ? "VETEL KERESES FEL..."
                                           : "VETEL KERESES LE...",
                       ST77XX_YELLOW, 30000U);
  irSeekStepStarted = millis();
  Serial.println(irSeekDirection > 0 ? "IR station seek up started"
                                     : "IR station seek down started");
}

void updateIrSeek() {
  if (irSeekPhase == IrSeekPhase::IDLE ||
      millis() - irSeekStepStarted < IR_SEEK_SETTLE_MS) {
    return;
  }

  radio.refreshReceptionStatus();
  updateRadioFields(false);
  const uint16_t frequency = radio.frequency();
  const uint16_t distanceFromStart =
      frequency > irSeekOriginalFrequency
          ? frequency - irSeekOriginalFrequency
          : irSeekOriginalFrequency - frequency;
  const bool outsideOriginalStation =
      distanceFromStart > RadioController::FREQUENCY_STEP;
  if (outsideOriginalStation && radio.stationValid() &&
      radio.rssi() >= AUTO_SCAN_MIN_RSSI) {
    finishIrSeek(true);
    return;
  }

  if (irSeekStepsChecked >= IR_SEEK_MAX_STEPS) {
    finishIrSeek(false);
    return;
  }

  radio.setFrequency(nextIrSeekFrequency(frequency, irSeekDirection));
  ++irSeekStepsChecked;
  updateRadioFields(false);
  irSeekStepStarted = millis();
}

void cancelIrSeek(bool showMessage) {
  if (irSeekPhase == IrSeekPhase::IDLE) {
    return;
  }

  irSeekPhase = IrSeekPhase::IDLE;
  radio.setFrequency(irSeekOriginalFrequency);
  activePreset = irSeekOriginalPreset;
  radio.setMuted(irSeekOriginalMuted);
  updateRadioFields(false);
  drawRdsStationName();
  drawRdsProgramText(0U);
  if (showMessage) {
    showTransientMessage("VETEL KERESES MEGSZAKITVA", ST77XX_YELLOW, 2200U);
  }
  Serial.println("IR station seek cancelled");
}

void executeIrAction(uint8_t action) {
  if (action >= IrSettingsStorage::ACTION_COUNT) {
    return;
  }

  const IrAction actionType = static_cast<IrAction>(action);
  const bool digitAction = isIrDigitAction(actionType);
  if (irSeekPhase != IrSeekPhase::IDLE) {
    if (actionType == IrAction::SEEK_UP ||
        actionType == IrAction::SEEK_DOWN) {
      return;
    }
    cancelIrSeek(false);
  }

  if (!digitAction && actionType != IrAction::CONFIRM) {
    clearIrChannelEntry(true);
  }

  const uint32_t now = millis();
  uint32_t minimumInterval = 350U;
  if (actionType == IrAction::VOLUME_UP ||
      actionType == IrAction::VOLUME_DOWN) {
    minimumInterval = 120U;
  } else if (actionType == IrAction::MUTE) {
    minimumInterval = 700U;
  } else if (actionType == IrAction::POWER) {
    minimumInterval = 1000U;
  } else if (actionType == IrAction::SEEK_UP ||
             actionType == IrAction::SEEK_DOWN) {
    minimumInterval = 1200U;
  } else if (digitAction) {
    minimumInterval = 120U;
  } else if (actionType == IrAction::CONFIRM) {
    minimumInterval = 500U;
  }
  if (lastIrActionAt[action] != 0U &&
      now - lastIrActionAt[action] < minimumInterval) {
    return;
  }
  lastIrActionAt[action] = now;

  if (actionType == IrAction::POWER) {
    enterInfraredStandby();
    return;
  }
  if (uiScreen != UiScreen::RADIO || !radio.available()) {
    return;
  }


  if (digitAction) {
    appendIrChannelDigit(irDigitValue(actionType));
    return;
  }
  if (actionType == IrAction::CONFIRM) {
    confirmIrChannelEntry();
    return;
  }

  switch (actionType) {
    case IrAction::CHANNEL_UP:
      stepStoredChannel(1);
      break;
    case IrAction::CHANNEL_DOWN:
      stepStoredChannel(-1);
      break;
    case IrAction::VOLUME_UP:
      radio.changeVolume(1);
      updateRadioFields(false);
      break;
    case IrAction::VOLUME_DOWN:
      radio.changeVolume(-1);
      updateRadioFields(false);
      break;
    case IrAction::MUTE:
      radio.toggleMute();
      updateRadioFields(false);
      break;
    case IrAction::SEEK_UP:
      startIrSeek(1);
      break;
    case IrAction::SEEK_DOWN:
      startIrSeek(-1);
      break;
    default:
      break;
  }
}

void processInfrared() {
  if (!irReceiver.decode(&irDecodeResults)) {
    return;
  }

  IrCodeData received;
  received.valid = true;
  received.protocol = static_cast<int16_t>(irDecodeResults.decode_type);
  received.bits = irDecodeResults.bits;
  received.value = irDecodeResults.value;
  received.address = irDecodeResults.address;
  received.command = irDecodeResults.command;
  const bool repeat = irDecodeResults.repeat;
  irReceiver.resume();

  const uint32_t now = millis();
  if (static_cast<int32_t>(now - irSuppressUntil) < 0) {
    return;
  }

  if (repeat) {
    if (!lastIrSignal.valid || now - lastIrSignalAt > 550U) {
      return;
    }
    received = lastIrSignal;
    lastIrSignalAt = now;
  } else {
    if (received.bits == 0U) {
      return;
    }
    lastIrSignal = received;
    lastIrSignalAt = now;
  }

  if (uiScreen == UiScreen::IR_LEARNING) {
    if (!repeat && !irLearningAdvancePending) {
      learnIrCode(received);
    }
    return;
  }

  for (uint8_t action = 0U; action < IrSettingsStorage::ACTION_COUNT;
       ++action) {
    if (irCodesEqual(irCodes[action], received)) {
      const IrAction matchedAction = static_cast<IrAction>(action);
      if (repeat && (matchedAction == IrAction::SEEK_UP ||
                     matchedAction == IrAction::SEEK_DOWN ||
                     isIrDigitAction(matchedAction) ||
                     matchedAction == IrAction::CONFIRM)) {
        return;
      }
      executeIrAction(action);
      return;
    }
  }
}

void processPresetButtons() {
  const PresetButtonEvent event = presetButtons.update();
  if (event.type == PresetButtonEventType::NONE) {
    return;
  }

  if (irSeekPhase != IrSeekPhase::IDLE) {
    cancelIrSeek(false);
  }

  if (irChannelEntryDigits != 0U) {
    clearIrChannelEntry(true);
  }

  if (uiScreen != UiScreen::RADIO) {
    noteMenuActivity();
    if (event.slot == 6U) {
      Serial.println("Button 6: save and leave menu");
      if (uiScreen == UiScreen::CHANNEL_NAME_EDITOR) {
        saveChannelNameEdit(true);
      } else {
        exitMenuToRadio();
      }
    }
    return;
  }

  if (event.type == PresetButtonEventType::LONG_PRESS) {
    saveCurrentStation(event.slot);
  } else if (event.type == PresetButtonEventType::SHORT_PRESS) {
    recallStoredStation(event.slot);
  }
}

void drawClockBuffered(const char *timeText) {
  int16_t boundsX = 0;
  int16_t boundsY = 0;
  uint16_t boundsWidth = 0;
  uint16_t boundsHeight = 0;

  clockCanvas.fillScreen(ST77XX_BLACK);
  clockCanvas.setTextWrap(false);
  clockCanvas.setTextSize(3);
  clockCanvas.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  clockCanvas.getTextBounds(timeText, 0, 0, &boundsX, &boundsY, &boundsWidth,
                            &boundsHeight);
  clockCanvas.setCursor(
      (CLOCK_CANVAS_WIDTH - static_cast<int16_t>(boundsWidth)) / 2, 0);
  clockCanvas.print(timeText);

  display.drawRGBBitmap(CLOCK_X, CLOCK_Y, clockCanvas.getBuffer(),
                        CLOCK_CANVAS_WIDTH, CLOCK_CANVAS_HEIGHT);
}

void updateRtcDisplay(bool force) {
  static uint32_t lastPollTime = 0;
  static uint32_t lastTimestamp = UINT32_MAX;
  static uint32_t lastDateKey = UINT32_MAX;
  static int16_t lastTemperatureQuarter = INT16_MIN;
  static bool missingMessageDrawn = false;
  const uint32_t nowMillis = millis();

  if (!force && nowMillis - lastPollTime < 200U) {
    return;
  }
  lastPollTime = nowMillis;

  if (!rtcAvailable) {
    if (force) {
      missingMessageDrawn = false;
    }
    if (!missingMessageDrawn) {
      display.fillRect(CLOCK_X, CLOCK_Y, CLOCK_CANVAS_WIDTH,
                       CLOCK_CANVAS_HEIGHT, ST77XX_BLACK);
      display.setTextColor(ST77XX_RED);
      display.setTextSize(1);
      display.setCursor(CLOCK_X + 34, CLOCK_Y + 8);
      display.print("DS3231 NINCS");
      missingMessageDrawn = true;
    }
    return;
  }

  const DateTime now = rtc.now();
  const uint32_t timestamp = now.unixtime();
  if (!force && timestamp == lastTimestamp) {
    return;
  }
  lastTimestamp = timestamp;

  char timeText[16];
  snprintf(timeText, sizeof(timeText), "%02u:%02u:%02u", now.hour(),
           now.minute(), now.second());
  drawClockBuffered(timeText);

  const uint8_t month = now.month();
  const uint32_t dateKey = static_cast<uint32_t>(now.year()) * 512U +
                           static_cast<uint32_t>(month) * 32U + now.day();
  if (force || dateKey != lastDateKey) {
    lastDateKey = dateKey;
    const char *monthName =
        month >= 1 && month <= 12 ? HUNGARIAN_MONTHS[month - 1] : "HIBAS";
    char dateText[32];
    snprintf(dateText, sizeof(dateText), "%04u-%s-%02u.", now.year(),
             monthName, now.day());
    display.fillRect(7, 91, 220, 18, ST77XX_BLACK);
    display.setTextColor(ST77XX_CYAN);
    display.setTextSize(2);
    display.setCursor(8, 92);
    display.print(dateText);
  }

  const float temperature = rtc.getTemperature();
  const int16_t temperatureQuarter =
      static_cast<int16_t>(temperature * 4.0F);
  if (force || temperatureQuarter != lastTemperatureQuarter) {
    lastTemperatureQuarter = temperatureQuarter;
    char temperatureText[16];
    // Per the requested final layout, only the value is shown, without a
    // separate "temperature" label.
    snprintf(temperatureText, sizeof(temperatureText), "%.2f C",
             static_cast<double>(temperature));
    display.fillRect(226, 91, 86, 18, ST77XX_BLACK);
    drawRightAlignedText(temperatureText, 312, 92, ST77XX_YELLOW, 2);
  }

}

uint16_t nextStartupLogoRandom(uint16_t &state) {
  // Small deterministic xorshift generator. A fixed seed keeps the animation
  // equally smooth at every start while the individual pixels still appear
  // in a scattered order.
  state ^= static_cast<uint16_t>(state << 7U);
  state ^= static_cast<uint16_t>(state >> 9U);
  state ^= static_cast<uint16_t>(state << 8U);
  return state;
}

uint16_t startupLogoPixel(int16_t x, int16_t y) {
  if (x < 0 || x >= static_cast<int16_t>(SzemmyLogo::WIDTH) || y < 0 ||
      y >= static_cast<int16_t>(SzemmyLogo::HEIGHT)) {
    return ST77XX_BLACK;
  }
  return pgm_read_word(
      &SzemmyLogo::PIXELS[static_cast<uint32_t>(y) * SzemmyLogo::WIDTH + x]);
}

void drawStartupLogo() {
  constexpr int16_t WAVE_WIDTH = 18;
  constexpr int16_t COLUMN_STEP = 2;
  constexpr uint16_t PARTICLES_PER_FRAME = 180;
  constexpr uint16_t FRAME_DELAY_MS = 7;
  constexpr uint16_t FINISHED_LOGO_HOLD_MS = 1100;

  display.fillScreen(ST77XX_BLACK);
  uint16_t randomState = 0xA53CU;

  // A scattered front moves from left to right. Pixels inside the front are
  // picked pseudo-randomly, while the two columns behind it are finalized on
  // every frame. This produces particles first and a complete logo behind
  // them without ever clearing an already drawn part.
  for (int16_t front = 0;
       front < static_cast<int16_t>(SzemmyLogo::WIDTH) + WAVE_WIDTH;
       front += COLUMN_STEP) {
    display.startWrite();

    for (uint16_t particle = 0; particle < PARTICLES_PER_FRAME; ++particle) {
      const int16_t x =
          front - static_cast<int16_t>(nextStartupLogoRandom(randomState) %
                                       WAVE_WIDTH);
      const int16_t y = static_cast<int16_t>(
          nextStartupLogoRandom(randomState) % SzemmyLogo::HEIGHT);
      const uint16_t color = startupLogoPixel(x, y);
      if (color != ST77XX_BLACK) {
        display.writePixel(x, y, color);
      }
    }

    const int16_t completedX = front - WAVE_WIDTH;
    for (int16_t offset = 0; offset < COLUMN_STEP; ++offset) {
      const int16_t x = completedX + offset;
      if (x < 0 || x >= static_cast<int16_t>(SzemmyLogo::WIDTH)) {
        continue;
      }
      for (int16_t y = 0; y < static_cast<int16_t>(SzemmyLogo::HEIGHT); ++y) {
        const uint16_t color = startupLogoPixel(x, y);
        if (color != ST77XX_BLACK) {
          display.writePixel(x, y, color);
        }
      }
    }

    display.endWrite();
    delay(FRAME_DELAY_MS);
  }

  // Copy the final image efficiently one scanline at a time. This guarantees
  // that every anti-aliased edge pixel is present before the hold period.
  uint16_t rowBuffer[SzemmyLogo::WIDTH];
  for (int16_t y = 0; y < static_cast<int16_t>(SzemmyLogo::HEIGHT); ++y) {
    for (int16_t x = 0; x < static_cast<int16_t>(SzemmyLogo::WIDTH); ++x) {
      rowBuffer[x] = startupLogoPixel(x, y);
    }
    display.drawRGBBitmap(0, y, rowBuffer, SzemmyLogo::WIDTH, 1);
  }
  delay(FINISHED_LOGO_HOLD_MS);
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println();
  Serial.println("Szemmy Radio - RDA5807 RDS and preset buttons 1-6");

  beginBacklight();
  loadDisplaySettings();
  loadIrSettings();

  displaySpi.begin(Pins::TFT_SCLK, -1, Pins::TFT_MOSI, Pins::TFT_CS);
  display.init(DisplayConfig::PANEL_WIDTH, DisplayConfig::PANEL_HEIGHT,
               SPI_MODE0);
  display.setRotation(displayRotation(displaySettings.flipped));
  display.invertDisplay(DisplayConfig::INVERT_COLORS);
  display.cp437(true);
  display.setTextWrap(false);
  display.fillScreen(ST77XX_BLACK);

  for (uint8_t level = 1; level <= displaySettings.brightness;
       ++level) {
    setBacklightLevel(level);
    delay(55);
  }

  beginI2cDevices();
  rotary.begin();
  presetButtons.begin();
  irReceiver.setUnknownThreshold(12U);
  irReceiver.enableIRIn(false);
  Serial.printf("IR receiver: GPIO%u, learning and light-sleep wake enabled\n",
                Pins::IR_INPUT);
  loadStoredPresets();
  const uint16_t startupFrequency =
      activePreset >= 1U && activePreset <= PresetStorage::CHANNEL_COUNT &&
              presets[activePreset - 1U].valid
          ? presets[activePreset - 1U].frequency
          : 10000U;
  radio.begin(rda5807Available, startupFrequency);

  drawStartupLogo();
  drawStaticRadioScreen();
  updateRadioFields(true);
  updateRdsDisplay();
  updateRtcDisplay(true);

  Serial.printf("Logical resolution: %d x %d\n", display.width(),
                display.height());
  Serial.printf("Backlight: %u / %u\n", currentBacklightLevel,
                DisplayConfig::BACKLIGHT_LEVELS);
  if (radio.available()) {
    Serial.printf("Radio starts with sound at %u.%u MHz, volume 1/15\n",
                  radio.frequency() / 100U,
                  (radio.frequency() % 100U) / 10U);
  }
}

void loop() {
  processInfrared();
  processRotary();
  processPresetButtons();
  if (uiScreen == UiScreen::RADIO) {
    if (irSeekPhase == IrSeekPhase::IDLE) {
      updateRadioStatus();
      updateRdsDisplay();
    } else {
      updateIrSeek();
    }
    updateRtcDisplay(false);
    updateIrChannelEntry();
    updateTransientMessage();
  } else {
    updateMenuScreen();
  }
  delay(2);
}

# Szemmy Radio – 17. lépés: infrás vételkeresés fel és le

Ez a változat a működő ST7789 kijelző, GPIO32-es PWM háttérvilágítás és
DS3231 óra mellé már elindítja az RDA5807 FM-vevőt is. A rádió és az RTC
közösen használja a GPIO21/GPIO22 I²C buszt.

A GPIO4-re kapcsolt infravevőhöz nyolc szabadon tanítható távirányító-funkció
tartozik: mentett csatorna fel/le, hangerő fel/le, némítás, ki/be kapcsolás,
valamint a következő vehető frekvencia megkeresése felfelé vagy lefelé. A
tanult kódok az ESP32 NVS memóriájában áramtalanítás után is megmaradnak.

Ez a lépés beolvassa és megjeleníti az RDS PS állomásnevet, valamint az RDS
RadioText üzenetet, amelyen az adóállomástól függően az előadó, a szám címe vagy
egyéb műsorinformáció jelenhet meg.

Bekapcsoláskor a `data/image/szemmy_logo.png` képből beágyazott Szemmy Radio
logó jelenik meg. A logó balról jobbra haladó, szórt képponthullámból épül fel,
majd rövid ideig teljes képként látható, mielőtt megjelenik a rádió főképernyője.
A kép közvetlenül a firmware része, ezért használatához nem szükséges SD-kártya
vagy külön feltöltött fájlrendszer.

Az 1–6 nyomógomb rövid megnyomásra előhívja a hozzá tartozó állomást, négy
másodperces nyomásra pedig kézzel menti az aktuális állomást az adott helyre.
Az automatikus FM-keresés a `CSATORNÁK` lista legfelső, külön sorából indítható.
A 20 csatorna frekvenciája és RDS-neve az ESP32 belső NVS memóriájába kerül,
ezért áramtalanítás után is megmarad.

A rádió minden bekapcsolás és áramszünet utáni újraindulás során hanggal, az
RDA5807 legalacsonyabb használható `1/15` hangerőértékével indul. Az utoljára
kiválasztott M1–M6 vagy C7–C20 memóriahely számát külön elmenti, ezért induláskor
közvetlenül annak frekvenciájára hangol. Ha még nincs ilyen adat, az első
érvényes mentett állomást választja; teljesen üres lista esetén `100.0 MHz` az
alapérték. A némítás később továbbra is a rotaryval megnyitható főmenü `HANG`
pontjában kapcsolható.

## Bekötés

### ST7789 kijelző

| ST7789 jelölés | ESP32 GPIO | Megjegyzés |
|---|---:|---|
| SCL / CLK | 18 | SPI órajel |
| SDA / DIN | 23 | SPI adat (MOSI) |
| RES / RST | 17 | Reset |
| DC | 16 | Adat/parancs választó |
| CS | 5 | Chip select |
| BLK vezérlés | 32 | AO3401A MOSFET kapuja, PWM fényerő |

### RDA5807 és DS3231 közös I²C busz

| Jel | ESP32 GPIO |
|---|---:|
| SDA | 21 |
| SCL | 22 |

A közös buszon a már beépített külső felhúzó ellenállások használatosak.
Az észlelt címek:

- RDA5807: `0x10` és/vagy `0x11`;
- DS3231: `0x68`;
- egyes RTC-panelen található EEPROM: `0x57`.

### Rotary encoder

| Rotary jel | ESP32 GPIO |
|---|---:|
| S1 | 25 |
| S2 | 26 |
| KEY | 27 |

A program aktív alacsony szintű encoderjeleket és külső 10 kΩ-os felhúzó
ellenállásokat feltételez. Ha a tekerési irány fordított, az
`include/control_config.h` fájlban az `ENCODER_REVERSED` értékét `true`-ra
kell állítani.

### Állomásgombok

| Memória | ESP32 GPIO |
|---|---:|
| M1 | 13 |
| M2 | 14 |
| M3 | 19 |
| M4 | 33 |
| M5 | 35 |
| M6 | 36 |

Mind a hat nyomógomb aktív alacsony szintű és külső 10 kΩ-os felhúzó
ellenállást használ. A GPIO35 és GPIO36 csak bemenet, belső felhúzójuk nincs;
a program ezért egyik állomásgombon sem engedélyez belső felhúzást.

### Infravevő

| Infravevő jel | ESP32 GPIO | Megjegyzés |
|---|---:|---|
| OUT / DATA | 4 | Aktív alacsony kimenet; light sleep ébresztés |
| VCC | 3,3 V | A használt vevőmodul adatlapja szerint |
| GND | GND | Közös föld |

A program nem kapcsol belső felhúzást a GPIO4-re. A szokásos TSOP/VS1838
vevőmodul saját digitális kimenete közvetlenül használható, de a modul
tápfeszültségét mindig a konkrét panel adatlapja alapján kell megválasztani.

## Állomásmemóriák kezelése

- Rövid `1–6` gombnyomás: a hozzá tartozó állomás betöltése.
- Az `M1–M6` legalább 4 másodperces nyomása: az aktuális frekvencia és RDS
  állomásnév kézi mentése az adott helyre.
- Sikeres kézi mentéskor például `M2 MENTVE: RADIO 1 107.5 MHz` jelenik meg.
- Betöltéskor például `M1 BETOLTVE: RADIO 1 107.5 MHz` jelenik meg.
- Üres memória kiválasztásakor figyelmeztető üzenet jelenik meg.
- Az első hat automatikusan talált adó az `M1–M6` fizikai gombokhoz kerül.
- A további találatok a menüben `C7–C20` jelöléssel érhetők el.
- Az aktív hely az állomásnév jobb oldalán `[M1]`–`[M6]` vagy `[C7]`–`[C20]`
  formában jelenik meg.
- Kézi frekvenciahangoláskor a memóriahely-jelzés megszűnik.

Ha mentéskor még nem érkezett RDS állomásnév, a program a frekvenciát tárolja
ideiglenes névként. Betöltés után az állomás valódi RDS-neve ismét megjelenik,
amint az adásból beérkezik.

## Kezelés ebben a tesztváltozatban

- Alaphelyzetben a rotary tekerése az RDA5807 hardveres hangerejét állítja
  `0–15` között.
- Alaphelyzetben egy rövid rotary-gombnyomás megnyitja a főmenüt.
- Hosszú, legalább 0,8 másodperces gombnyomás belép a frekvenciahangolásba.
- Hangoláskor a tekerő `0,1 MHz` lépésekkel mozog `87,5–108,0 MHz` között.
- Hangoláskor egy rövid gombnyomás visszalép a hangerőszabályozásba.
- Hangoláskor újabb hosszú gombnyomás szintén visszalép.

A némítás a főmenü `HANG: SZÓL / NÉMÍTVA` pontjával kapcsolható. A rádió
hangolása, hangereje és az 1–6 állomásmemória működése változatlan maradt.

Minden sikeres állomásbetöltés és kézi M1–M6 mentés frissíti az „utolsó
csatorna” adatot. Egy sikeresen befejezett automata keresés után az első talált
állomás lesz az induló csatorna. A kézi frekvenciahangolás nem törli ezt az
adatot, ezért újraindításkor továbbra is a legutóbb kiválasztott mentett
csatorna tér vissza.

## Főmenü és óra/dátum beállítás

- Rövid rotary-gombnyomással megnyílik a főmenü.
- A tekerővel lehet a menüpontok között körbe navigálni, rövid nyomással pedig
  belépni a kiválasztott pontba.
- Az `ÓRA / DÁTUM` menüben az óra, perc, másodperc, év, hónap és nap külön
  választható ki.
- A kiválasztott mező rövid rotary-nyomás után villog; ekkor a tekerő módosítja
  az értékét.
- Újabb rövid nyomás a következő mezőre lép. A nap után a `KÉSZ` pont lesz
  kijelölve, amely visszavisz a főmenübe.
- Minden megváltoztatott érték azonnal bekerül a DS3231-be.
- A 6-os nyomógomb bármelyik menüből mentéssel visszalép a rádióképernyőre.
- Öt másodperc tétlenség után a program automatikusan visszalép a
  rádióképernyőre; a már módosított értékek ilyenkor is megmaradnak.
- A `CSATORNÁK` pont megnyitja a 20 tartós állomásmemória böngészhető listáját.
- Az `INFRA TANÍTÁS` pont megnyitja a távirányító 19 funkciójának tanítását.

## Infravezérlés tanítása és használata

- A főmenü `INFRA TANÍTÁS` pontja az első még be nem tanított funkcióra ugrik.
  Ha mind a 19 funkció be van állítva, a `CSATORNA FEL` jelenik meg elsőként.
- Nyomd meg a használni kívánt távirányítógombot. A kijelző kiírja a felismert
  protokollt, a bithosszt és a hexadecimális kódot.
- A kód azonnal elmentődik, majd egy másodperc után automatikusan megjelenik a
  következő funkció.
- A tanítás sorrendje: `CSATORNA FEL`, `CSATORNA LE`, `HANGERŐ FEL`,
  `HANGERŐ LE`, `NÉMÍTÁS`, `KI / BE`, `KERESÉS FEL`, `KERESÉS LE`, majd a
  `SZÁM 0`–`SZÁM 9` gombok és végül az `OK / BETÖLT`.
- A rotary tekerésével bármelyik funkció kiválasztható és újratanítható. Rövid
  rotary-nyomás tanítás nélkül a következő funkcióra lép.
- Ugyanaz az infragomb nem rendelhető két külön funkcióhoz; ilyen esetben a
  kijelző figyelmeztet, és az aktuális funkción marad.
- A 6-os fizikai gomb bármikor visszalép a rádióképernyőre. A már megtanított
  gombok ekkor is megmaradnak.
- Az infratanító képernyő 30 másodperc tétlenség után lép ki, hogy legyen idő a
  távirányító előkészítésére. A többi menü 5 másodperces ideje nem változott.
- A csatorna fel/le csak az érvényes M1–M6 és C7–C20 állomásokat járja körbe;
  az üres memóriahelyeket automatikusan átugorja.
- A számgombokkal közvetlenül megadható az 1–20 közötti memóriahely. Például
  `1`, `2`, majd `OK` megnyomására a rádió a 12-es csatornára vált. A beírt
  szám a rádióképernyő alsó információs sorában látható.
- A megadott szám öt másodperc tétlenség után törlődik. Két számjegy után egy
  újabb számgomb új bevitelt kezd, így külön törlésgomb nélkül is javítható az
  elütés. A `0`, illetve a 20-nál nagyobb szám nem választható ki; üres
  memóriahely esetén a kijelző ezt külön jelzi.
- A távirányító ismétlőkódja nem írja be többször ugyanazt a számot, és az
  `OK` műveletet sem hajtja végre kétszer.
- A hangerőgomb nyomva tartása ismétlődik, a némítás, a ki-/bekapcsolás és a
  vételkeresés pedig védett a távirányító ismétlőkódja okozta dupla
  végrehajtástól.
- A `KERESÉS FEL` és `KERESÉS LE` nem a mentett húsz csatorna között mozog.
  A jelenlegi frekvenciától 0,1 MHz-es lépésekben, a húszcsatornás automatikus
  kereséssel azonos `FM_TRUE` és legalább 10-es RSSI feltétellel vizsgálja a
  sávot. A keresés közben az éppen vizsgált frekvencia folyamatosan látható a
  kijelzőn, a sávhatáron pedig körbefordul.
- A kiinduló állomás közvetlen ±0,1 MHz-es szomszédját nem tekinti új
  találatnak, mert egy erős adó ezen a két frekvencián még önmagát jelezheti.
- A rádió a keresés idejére elnémul. Találatkor visszaáll az előző némítási
  állapot, megjelenik az új frekvencia, és megkezdődik az új állomás
  RDS-adatainak beolvasása.
- Ha a teljes FM-sávban nincs másik vehető állomás, az eredeti frekvencia és
  memóriahely marad meg.
- A rotary, valamelyik fizikai memória-gomb vagy más infrás funkció használata
  megszakítja a folyamatot és biztonságosan visszaállítja a kiinduló állomást.

A `KI / BE` funkció először elnémítja a rádiót, kikapcsolja a ST7789 panelt és
a GPIO32-es háttérvilágítást, majd az ESP32-t light sleep állapotba teszi. A
GPIO4 következő alacsony infrapulzusa felébreszti a készüléket; ezután a kijelző
és az alvás előtti némítási állapot visszaáll. Alvás közben az ESP32 még nem tud
teljes infrakódot dekódolni, ezért a betanított ki-/bekapcsoló gomb mellett más
infravillanás is felébresztheti, de a rádió többi funkciója csak a hozzájuk
betanított teljes kódra reagál.

## Képernyő beállítása

- A főmenü `KÉPERNYŐ` pontja megnyitja a fényerő- és tájolásbeállítást.
- A `FÉNYERŐ` értéke `1–15` között állítható, és a változás azonnal látható a
  háttérvilágításon.
- A `FLIP` értéke `KI` vagy `BE`; bekapcsolva a teljes ST7789 képet 180 fokkal
  megfordítja.
- A kiválasztott érték rotary-nyomás után villog, a tekerő ekkor módosítja.
- Újabb rotary-nyomás a következő mezőre, majd a `KÉSZ` pontra lép.
- A `KÉSZ`, a 6-os gomb és az 5 másodperces automatikus kilépés is elmenti a
  fényerőt és a flip állapotát.
- A kijelzőbeállítások az ESP32 külön `szemmy_disp` NVS-területén tárolódnak,
  ezért áramtalanítás és újraindítás után is megmaradnak.
- Bekapcsoláskor a program már az elmentett fényerőre fut fel és az elmentett
  tájolással rajzolja ki a rádióképernyőt.

## Csatornalista

- A lista összesen 20 memóriahelyet kezel: `M1–M6` és `C7–C20`.
- A memóriahelyek előtt egy középre igazított, számozatlan `AUTOMATA KERESÉS`
  sor található. Rövid rotary-nyomás ezen a soron elindítja a teljes FM-keresést.
- A lista megnyitásakor ez a keresősor van kijelölve, így a keresés egy újabb
  rövid rotary-nyomással azonnal indítható.
- A korábbi apró betű helyett kétszeres méretű szöveget használ.
- Egyszerre négy nagy sor látható; a lista a kijelöléssel automatikusan gördül.
- Minden érvényes sor megjeleníti a memóriahelyet, a mentett
  állomásnevet és a frekvenciát.
- Az aktuálisan szóló memóriahelyet zöld `>` jelzi.
- Az üres helyek `-- ÜRES --` jelölést kapnak.
- A rotary tekerésével a kijelölés az automata keresés és a 20 memóriahely
  között körbefordul.
- Rövid rotary-nyomás betölti a kiválasztott állomást, majd azonnal visszalép a
  rádióképernyőre.
- Egy érvényes állomáson a rotary gombját 4 másodpercig nyomva tartva megnyílik
  a csatornanév-szerkesztő. Az üres memóriahelyek nem nevezhetők át.
- Üres sor kiválasztásakor figyelmeztetés jelenik meg, és a lista nyitva marad.
- A 6-os gomb vagy 5 másodperc tétlenség állomásváltás nélkül visszalép a
  rádióképernyőre.
- Az első hat sor ugyanazokat az NVS-adatokat használja, mint az 1–6 fizikai
  nyomógomb, így nincs külön vagy egymástól eltérő tárolás.

## Csatornanév-szerkesztő

- A név legfeljebb 8 karakteres lehet, ugyanúgy, mint az RDS PS állomásnév.
- A virtuális billentyűzet 8×4 nagy mezőből áll. A rotary tekerése mozgatja a
  kijelölést, rövid megnyomása beírja a kiválasztott karaktert vagy végrehajtja
  a funkciót.
- Külön oldal érhető el a kisbetűkhöz, nagybetűkhöz, számokhoz és speciális
  karakterekhez.
- A magyar oldal az `áéíóöőúüű` karaktereket és ezek nagybetűs változatait is
  tartalmazza. Ezekhez a firmware saját 5×7 képpontos magyar karakterkészletet
  használ, ezért az `ő`, `ű`, `Ő` és `Ű` is valóban megjelenik.
- A `<-` gomb az utolsó karaktert törli, az `SP` szóközt ír be.
- Az `OK` elmenti a nevet és visszatér a csatornalistába.
- A fizikai 6-os gomb elmenti a nevet, majd közvetlenül visszalép a
  rádióképernyőre.
- Öt másodperc tétlenség mentés nélkül visszalép a rádióképernyőre, így egy
  félbehagyott szerkesztés nem írja felül a korábbi nevet.
- A mentett név ugyanabba az NVS-adatba kerül, amelyet a csatornalista és az
  M1–M6 gombok is használnak; áramtalanítás után is megmarad.

## Automatikus FM-keresés

- A főmenü `CSATORNÁK` pontjában a lista legfelső `AUTOMATA KERESÉS` sorát kell
  kiválasztani, majd röviden megnyomni a rotary gombját.
- A keresés 87,5 és 108,0 MHz között, 0,1 MHz-es lépésekben vizsgálja a sávot.
- A vevő minden lépés után megvárja az RDA5807 beállását, és csak a chip által
  valódi FM-adónak jelzett, megfelelő RSSI-szintű frekvenciát fogadja el.
- A keresés alatt a rádió elnémul, így a gyors frekvenciaváltások nem jutnak a
  külső erősítőre.
- Legfeljebb 20 találat kerül a listába. Az első hat automatikusan az M1–M6
  gombokhoz rendelődik.
- Találat után a program legfeljebb 1,8 másodpercig vár az RDS PS névre.
- Az RDS-nevet csak rövid stabilitás-ellenőrzés után menti el, így nem kerül a
  listába félkész névtöredék.
- Ha nem érkezik használható RDS-név, `N/A` kerül a név helyére, a frekvencia
  ettől függetlenül megmarad.
- A keresőképernyő mutatja az aktuális frekvenciát, a sáv előrehaladását, a
  találatok számát és a legutóbbi állomás nevét/frekvenciáját.
- A keresőképernyő változó része először memóriapufferben készül el, majd egyben
  kerül a kijelzőre. A kijelzés legfeljebb négyszer frissül másodpercenként,
  miközben a rádió a háttérben változatlan sebességgel vizsgálja a frekvenciákat.
  Így a gyors, üres frekvencialépések közben sem villan fel a teljes képernyő.
- A 6-os gombbal vagy rövid rotary-nyomással a keresés megszakítható. Ilyenkor
  a korábbi 20-as lista, az eredeti frekvencia és a némítás állapota visszaáll.
- A lista csak a teljes keresés végén kerül NVS-be; egy félbeszakított keresés
  nem írja felül a régi állomásokat.
- Ha a keresés egyetlen állomást sem talál, szintén érintetlenül hagyja a régi
  listát és visszaállítja az eredeti frekvenciát.
- Sikeres befejezés után az első talált állomás kapcsol be, és visszaáll a
  keresés előtti némítási állapot.

Az RDA5807 áramkör belső hangerőszabályzója fizikailag csak 16 értéket ismer
(`0–15`). Ez a lépés közvetlenül ezeket használja; a külső erősítőhöz szükséges
finomabb, akár 100 fokozatú hangerőgörbe külön szoftveres vagy hardveres
csillapítást igényel.

## Kijelzés

A képernyőn látható:

- legfelül az RDS állomásnév;
- alatta az RDS RadioText; a hosszú szöveg automatikusan gördül;
- az aktuális FM-frekvencia és az óra egyaránt 3×-os méretben, azonos sorban;
- a monó/sztereó vétel;
- az RDA5807 `0–63` közötti RSSI jelszintje;
- az állomásérzékelés eredménye;
- az RDS szinkronizáció `RDS:OK` vagy `RDS:--` állapota;
- az aktív állomásmemória `[M1]`–`[M6]` jelzése;
- a hangerő és a némítás állapota;
- a rotary aktuális üzemmódja a kijelző legalsó sorában;
- a DS3231 órája és a hangerő alatti sorban a magyar hónapnevű dátuma;
- a DS3231 hőmérséklete kizárólag értékként, külön „HŐMÉRSÉKLET” felirat nélkül.

Az óra továbbra is memóriapufferből, villogásmentesen frissül. A teljes képernyő
nem rajzolódik újra másodpercenként. A rádió állapotmezői is csak tényleges
változáskor frissülnek.

Frekvenciaváltáskor a program azonnal törli az előző állomás RDS-adatait, így
nem marad a kijelzőn másik adó neve vagy műsorcíme. Az új RDS-információ
beolvasása néhány másodpercet igényelhet, és csak olyan állomáson működik, amely
RDS-adást sugároz, megfelelő térerővel. A jelenlegi alapbetűkészlet az ASCII
karaktereket kezeli; az RDS különleges és ékezetes karaktereit később a projekt
magyar fontkészletével egészítjük ki.

A korábbi próba-VU, a „VU TESZT” felirat és az animációnak fenntartott üres sor
kikerült. A felszabadult területet a nagyobb frekvencia- és órakijelzés kapta,
az alsó kezelési sor pedig feljebb került.

## Rádióbeállítások

- európai/USA FM-sáv;
- `87,5–108,0 MHz` kézi tartomány;
- `100 kHz` hangolási lépés;
- európai `50 µs` deemphasis;
- soft mute és soft blend engedélyezve;
- RDS-vevő engedélyezve;
- PS állomásnév beolvasása, legfeljebb 8 karakter;
- 2A és 2B RadioText beolvasása, legfeljebb 64 karakter;
- RDS-lekérdezés 50 ms-onként, a kijelző teljes újrarajzolása nélkül.

A projektbe be van másolva a PU2CLR RDA5807 könyvtár `1.1.9` változata, ezért
a forrás a kijelző- és RTC-könyvtárakkal együtt önállóan fordítható.

Az infravételhez a projekt `src/IRremoteESP8266` mappájában található
IRremoteESP8266 `2.9.0` forrás használatos. A fordítás a leggyakoribb NEC,
RC5, RC6, Sony, Panasonic, JVC, Samsung, LG, Sharp és Denon protokollokat
engedélyezi; minden más impulzusalapú távirányítóhoz rendelkezésre áll az
általános RAW/HASH tanítási mód.

## Fordítás és feltöltés

A projekt PlatformIO-hoz készült:

- célpanel: `esp32dev`;
- vezérlő: klasszikus ESP32-WROOM-32;
- Arduino-ESP32: `3.3.7`;
- soros monitor: `115200` baud;
- flash: `4 MB`, DIO, `40 MHz`.

Fordítás:

```text
pio run
```

Feltöltés USB-n:

```text
pio run -t upload
```

Az előre lefordított
`Szemmy_Radio_IR_NUMERIC_merged_0x0000.bin` tartalmazza a
bootloadert, a partíciós táblát és az alkalmazást. ESP32 Flash Download Tool
használatakor ezt az egy fájlt a **0x0000** címre kell írni.

A `Szemmy_Radio_IR_NUMERIC_app_0x10000.bin` csak az alkalmazást
tartalmazza. Ha a teljes `merged.bin` már legalább egyszer felkerült, a későbbi
frissítéseknél az alkalmazásfájlt a **0x10000** címre írva az NVS-ben tárolt
állomásmemóriák megmaradnak. A teljes, 0x0000 címre írt firmware-frissítés az
NVS-területet is törölheti, ezért utána szükség lehet az állomások újramentésére.

## Még nem része ennek a lépésnek

- valódi audio-VU mérés;
- a kijelzőszínek felhasználói beállítása és tartós mentése.
